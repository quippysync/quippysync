<?php

$userrT56sQ2 = "dirsyncsql";
$passjt67eRc = "quippysync";
$dbrtGd452Wer = "ad_template";

$con = mysqli_connect("localhost",$userrT56sQ2,$passjt67eRc);

mysqli_select_db($con,$dbrtGd452Wer);

?>