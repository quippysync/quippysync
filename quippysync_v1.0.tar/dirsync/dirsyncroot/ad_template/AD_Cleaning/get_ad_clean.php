<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Make connection to the database
$mysql_con = $argv[1];
include($mysql_con);

# Set the path to where the data will be saved
$iter_path = $argv[2];

# Export accounts from g_disabled to be removed
$ad_clean_file1 = fopen($iter_path . "/ad_clean_disabled.txt", "w") or die("Unable to open file!");
$sel1 = mysqli_query($con,"SELECT accountid FROM ad_disabled WHERE remove1 = 1");
while($rec = mysqli_fetch_array($sel1))
{
    fwrite($ad_clean_file1, $rec['accountid'] . "\n");
}
fclose($ad_clean_file1);

# Export accounts from g_ou_exemptions to be removed
$ad_clean_file2 = fopen($iter_path . "/ad_clean_exemptions.txt", "w") or die("Unable to open file!");
$sel2 = mysqli_query($con,"SELECT accountid FROM ad_ou_exemptions WHERE remove1 = 1");
while($rec2 = mysqli_fetch_array($sel2))
{
    fwrite($ad_clean_file2, $rec2['accountid'] . "\n");
}
fclose($ad_clean_file2);

# Close the connection to the database
mysqli_close($con);

?>