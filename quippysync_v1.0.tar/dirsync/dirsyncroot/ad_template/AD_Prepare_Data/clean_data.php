<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("inc-format_win_time.php");

# Make connection to the database
$mysql_con = $argv[1];
include($mysql_con);

# Get last imported attribute of ad_master_data so trailing spaces can be removed
    $ad_master_attrib_string = $argv[2];
    $attribArr1 = explode(",",$ad_master_attrib_string);
    $lastMasterAttrib = $attribArr1[count($attribArr1)-1];

# Get last imported attribute of ad_data so trailing spaces can be removed
    $ad_data_attrib_string = $argv[3];
    $attribArr2 = explode(",",$ad_data_attrib_string);
    $lastDataAttrib = $attribArr2[count($attribArr2)-1];

# Get last imported attribute of ad_disabled so trailing spaces can be removed
    $ad_disabled_attrib_string = $argv[4];
    $attribArr3 = explode(",",$ad_disabled_attrib_string);
    $lastDisabledAttrib = $attribArr3[count($attribArr3)-1];

# Get last imported attribute of ad_ou_exemptions so trailing spaces can be removed
    $ad_exempt_attrib_string = $argv[5];
    $attribArr4 = explode(",",$ad_exempt_attrib_string);
    $lastExemptAttrib = $attribArr4[count($attribArr4)-1];

# Remove extra time data for creation_time  from date fields
    mysqli_query($con,"UPDATE ad_data SET creation_time = MID(creation_time,1,8)");
    mysqli_query($con,"UPDATE ad_disabled SET creation_time = MID(creation_time,1,8)");
    mysqli_query($con,"UPDATE ad_ou_exemptions SET creation_time = MID(creation_time,1,8)");

# Format last_logon fields
# NOTE: The last_logon_temp field needs to be unsigned to keep it from having a negative value
    mysqli_query($con,"UPDATE ad_data SET last_logon_temp = FROM_UNIXTIME(last_logon / 10000000 - 11644473600,'%Y%m%d')");
    mysqli_query($con,"UPDATE ad_data SET last_logon = last_logon_temp");
    
    mysqli_query($con,"UPDATE ad_disabled SET last_logon_temp = FROM_UNIXTIME(last_logon / 10000000 - 11644473600,'%Y%m%d')");
    mysqli_query($con,"UPDATE ad_disabled SET last_logon = last_logon_temp");
    
    mysqli_query($con,"UPDATE ad_ou_exemptions SET last_logon_temp = FROM_UNIXTIME(last_logon / 10000000 - 11644473600,'%Y%m%d')");
    mysqli_query($con,"UPDATE ad_ou_exemptions SET last_logon = last_logon_temp");

# Remove trailing returns of the last attribute
    mysqli_query($con,"UPDATE ad_master_data SET " . $lastMasterAttrib . " = REPLACE(" . $lastMasterAttrib . ",'\r','')");
    mysqli_query($con,"UPDATE ad_master_data SET " . $lastMasterAttrib . " = REPLACE(" . $lastMasterAttrib . ",'\t','')");
    mysqli_query($con,"UPDATE ad_master_data SET " . $lastMasterAttrib . " = REPLACE(" . $lastMasterAttrib . ",'\n','')");
    
    mysqli_query($con,"UPDATE ad_data SET " . $lastDataAttrib . " = REPLACE(" . $lastDataAttrib . ",'\r','')");
    mysqli_query($con,"UPDATE ad_data SET " . $lastDataAttrib . " = REPLACE(" . $lastDataAttrib . ",'\t','')");
    mysqli_query($con,"UPDATE ad_data SET " . $lastDataAttrib . " = REPLACE(" . $lastDataAttrib . ",'\n','')");
    
    mysqli_query($con,"UPDATE ad_disabled SET " . $lastDisabledAttrib . " = REPLACE(" . $lastDisabledAttrib . ",'\r','')");
    mysqli_query($con,"UPDATE ad_disabled SET " . $lastDisabledAttrib . " = REPLACE(" . $lastDisabledAttrib . ",'\t','')");
    mysqli_query($con,"UPDATE ad_disabled SET " . $lastDisabledAttrib . " = REPLACE(" . $lastDisabledAttrib . ",'\n','')");
    
    mysqli_query($con,"UPDATE ad_ou_exemptions SET " . $lastExemptAttrib . " = REPLACE(" . $lastExemptAttrib . ",'\r','')");
    mysqli_query($con,"UPDATE ad_ou_exemptions SET " . $lastExemptAttrib . " = REPLACE(" . $lastExemptAttrib . ",'\t','')");
    mysqli_query($con,"UPDATE ad_ou_exemptions SET " . $lastExemptAttrib . " = REPLACE(" . $lastExemptAttrib . ",'\n','')");

# Make all accountid fields lower case
    mysqli_query($con,"UPDATE ad_master_data SET accountid = LCASE(accountid)");
    mysqli_query($con,"UPDATE ad_data SET accountid = LCASE(accountid)");
    mysqli_query($con,"UPDATE ad_disabled SET accountid = LCASE(accountid)");
    mysqli_query($con,"UPDATE ad_ou_exemptions SET accountid = LCASE(accountid)");


# Close the connection to the database
mysqli_close($con);

?>