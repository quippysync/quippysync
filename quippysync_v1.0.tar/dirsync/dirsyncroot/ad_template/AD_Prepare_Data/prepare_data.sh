#!/bin/bash

#     Copyright 2015 Anthony Tranquillo

#     This file is part of Quippysync.

#    Quippysync is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Quippysync is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Clean data
    $php_path ./dirsyncroot/$iter/AD_Prepare_Data/clean_data.php $mysql_con "$ad_master_attrib_string" "$ad_data_attrib_string" "$ad_disabled_attrib_string" "$ad_ous_exemptions_attrib_string" 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Prepare_Data/clean_data.php" "FAIL: Call $iter/AD_Prepare_Data/clean_data.php" 2;
        checkLog "php" "FAIL: Error in $iter/AD_Prepare_Data/clean_data.php" 10;
    
# Prepare data
    $php_path ./dirsyncroot/$iter/AD_Prepare_Data/prepare_data.php $mysql_con "$ad_fqdn_suffix" "$remove_name_chars" 1>> $iter_path/php.log 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Prepare_Data/prepare_data.php" "FAIL: Call $iter/AD_Prepare_Data/prepare_data.php" 2;
        checkLog "php" "FAIL: Error in $iter/AD_Prepare_Data/prepare_data.php" 10;
    
# Check data
    $php_path ./dirsyncroot/$iter/AD_Prepare_Data/check_data.php $mysql_con "$ad_regex" 1>> $iter_path/php.log 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Prepare_Data/check_data.php" "FAIL: Call $iter/AD_Prepare_Data/check_data.php" 2;
        checkLog "php" "FAIL: Error in $iter/AD_Prepare_Data/check_data.php" 10;

###### Last chance to manipulate data before it gets analyzed and executed


