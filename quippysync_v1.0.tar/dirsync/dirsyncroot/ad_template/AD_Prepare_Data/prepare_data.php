<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Make connection to the database
$mysql_con = $argv[1];
include($mysql_con);

# Get the domain suffix
$g_fqdn_suffix = $argv[2];

# Get the remove name chars option
$remove_name_chars = $argv[3];

# Remove domain name
mysqli_query($con,"UPDATE ad_data SET accountid = REPLACE(accountid, '@" . $g_fqdn_suffix . "', '') WHERE accountid LIKE '%@" . $g_fqdn_suffix . "'");
mysqli_query($con,"UPDATE ad_disabled SET accountid = REPLACE(accountid, '@" . $g_fqdn_suffix . "', '') WHERE accountid LIKE '%@" . $g_fqdn_suffix . "'");
mysqli_query($con,"UPDATE ad_ou_exemptions SET accountid = REPLACE(accountid, '@" . $g_fqdn_suffix . "', '') WHERE accountid LIKE '%@" . $g_fqdn_suffix . "'");

# Remove spaces . - ' from account names
if($remove_name_chars == 1)
{
	mysqli_query($con,"UPDATE ad_master_data SET accountid = REPLACE(accountid, ' ', '')");
	mysqli_query($con,"UPDATE ad_master_data SET accountid = REPLACE(accountid, '.', '')");
	mysqli_query($con,"UPDATE ad_master_data SET accountid = REPLACE(accountid, '-', '')");
	mysqli_query($con,"UPDATE ad_master_data SET accountid = REPLACE(accountid, '\'', '')");
}

# Close the connection to the database
mysqli_close($con);

?>