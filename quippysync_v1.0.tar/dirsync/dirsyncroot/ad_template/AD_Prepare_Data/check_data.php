<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Make connection to the database
$mysql_con = $argv[1];
include($mysql_con);

# Get regex string
$ad_regex = $argv[2];

# Make sure all date matches regexs in the regex string
foreach(explode("|1>",$ad_regex) as $field)
{
	$val = explode("|0>",$field);
			
	$sel = mysqli_query($con,"SELECT " . $val[1] . " FROM " . $val[0]);
	while($rec = mysqli_fetch_array($sel))
	{
		if(!preg_match($val[2],$rec[$val[1]]))
		{
			echo "Illegal Characters in " . $val[0] . "." . $val[1] . "\n";
		}
	}
}

# Make sure ad_master_data has no duplicates
$dupSel = mysqli_query($con,"SELECT accountid FROM ad_master_data GROUP BY accountid HAVING COUNT(accountid) > 1");
if(mysqli_num_rows($dupSel) > 0)
{
	echo "There is at least one duplicate value in ad_master_data.accountid";
}

# Close the connection to the database
mysqli_close($con);

?>