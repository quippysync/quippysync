<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Make connection to the database
$mysql_con = $argv[1];
include($mysql_con);

// Remove exemptions from ad_data
$sel_data = "UPDATE ad_data INNER JOIN exemptions ON ad_data.accountid = exemptions.exemption SET ";
$sel_data .= "ad_data.exempt = 1 WHERE exemptions.type = 1";
mysqli_query($con,$sel_data);
mysqli_query($con,"DELETE FROM ad_data WHERE exempt = 1");

// Remove exemptions from ad_master_data
$sel_master = "UPDATE ad_master_data INNER JOIN exemptions ON ad_master_data.accountid = exemptions.exemption SET ";
$sel_master .= "ad_master_data.exempt = 1 WHERE exemptions.type = 1";
mysqli_query($con,$sel_master);
mysqli_query($con,"DELETE FROM ad_master_data WHERE exempt = 1");

// Remove exemptions from ad_disabled
$sel_disabled = "UPDATE ad_disabled INNER JOIN exemptions ON ad_disabled.accountid = exemptions.exemption SET ";
$sel_disabled .= "ad_disabled.exempt = 1 WHERE exemptions.type = 1";
mysqli_query($con,$sel_disabled);
mysqli_query($con,"DELETE FROM ad_disabled WHERE exempt = 1");

# Close the connection to the database
mysqli_close($con);

?>