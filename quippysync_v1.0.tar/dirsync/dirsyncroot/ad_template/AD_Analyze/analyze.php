<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Make connection to the database
$mysql_con = $argv[1];
include($mysql_con);

# Set the path to where the data will be saved
$iter_path = $argv[2];

// Get max create, disable, move, and enable
$max_create = $argv[3];
$max_disable = $argv[4];
$max_move = $argv[5];
$max_enable = $argv[6];

//////////////////////////////////////////Copy data between tables////////////////////////////

//Copy data from ad_data table to ad_master_data
$sel_ad_to_master = "UPDATE ad_master_data INNER JOIN ad_data ON ad_master_data.accountid = ad_data.accountid SET ";
$sel_ad_to_master .= "ad_master_data.ad_ou = ad_data.ou, ";
$sel_ad_to_master .= "ad_master_data.ad_dn = ad_data.dn, ";
$sel_ad_to_master .= "ad_master_data.ad_attrib1 = ad_data.attrib1, ";
$sel_ad_to_master .= "ad_master_data.ad_attrib2 = ad_data.attrib2, ";
$sel_ad_to_master .= "ad_master_data.ad_attrib3 = ad_data.attrib3, ";
$sel_ad_to_master .= "ad_master_data.ad_attrib4 = ad_data.attrib4";
mysqli_query($con,$sel_ad_to_master);

//Copy data from ad_data_master table to ad_data
//This section must come before the section where ad_data joins ad_ous because the section where ad_data joins ad_ous depends on ad_data.master_ou to be populated so it can populate ad_data.master_group1
$sel_master_to_ad = "UPDATE ad_data INNER JOIN ad_master_data ON ad_data.accountid = ad_master_data.accountid SET ";
$sel_master_to_ad .= "ad_data.master_ou = ad_master_data.ou, ";
$sel_master_to_ad .= "ad_data.master_first_name = ad_master_data.first_name, ";
$sel_master_to_ad .= "ad_data.master_last_name = ad_master_data.last_name, ";
$sel_master_to_ad .= "ad_data.master_attrib1 = ad_master_data.attrib1, ";
$sel_master_to_ad .= "ad_data.master_attrib2 = ad_master_data.attrib2, ";
$sel_master_to_ad .= "ad_data.master_attrib3 = ad_master_data.attrib3, ";
$sel_master_to_ad .= "ad_data.master_attrib4 = ad_master_data.attrib4";
mysqli_query($con,$sel_master_to_ad);

//Copy data from OUs table to ad_master_data
$sel_master = "UPDATE ad_master_data INNER JOIN ad_ous ON ad_master_data.ou = ad_ous.ou SET ";
$sel_master .= "ad_master_data.ous_group1 = ad_ous.group1, ";
$sel_master .= "ad_master_data.ous_dn = ad_ous.dn, ";
$sel_master .= "ad_master_data.ous_script = ad_ous.script, ";
$sel_master .= "ad_master_data.ous_storage_path = ad_ous.storage_path, ";
$sel_master .= "ad_master_data.ous_drive_letter = ad_ous.drive_letter, ";
$sel_master .= "ad_master_data.ous_server_name = ad_ous.server_name, ";
$sel_master .= "ad_master_data.ous_user_share = ad_ous.user_share, ";
$sel_master .= "ad_master_data.ous_attrib1 = ad_ous.attrib1, ";
$sel_master .= "ad_master_data.ous_attrib2 = ad_ous.attrib2, ";
$sel_master .= "ad_master_data.ous_attrib3 = ad_ous.attrib3, ";
$sel_master .= "ad_master_data.ous_attrib4 = ad_ous.attrib4";
mysqli_query($con,$sel_master);

//Copy data from OUs table to ad_data
$sel_ad = "UPDATE ad_data INNER JOIN ad_ous ON ad_data.ou = ad_ous.ou SET ";
$sel_ad .= "ad_data.ous_group1 = ad_ous.group1, ";
$sel_ad .= "ad_data.ous_dn = ad_ous.dn, ";
$sel_ad .= "ad_data.ous_script = ad_ous.script, ";
$sel_ad .= "ad_data.ous_storage_path = ad_ous.storage_path, ";
$sel_ad .= "ad_data.ous_drive_letter = ad_ous.drive_letter, ";
$sel_ad .= "ad_data.ous_server_name = ad_ous.server_name, ";
$sel_ad .= "ad_data.ous_user_share = ad_ous.user_share, ";
$sel_ad .= "ad_data.ous_attrib1 = ad_ous.attrib1, ";
$sel_ad .= "ad_data.ous_attrib2 = ad_ous.attrib2, ";
$sel_ad .= "ad_data.ous_attrib3 = ad_ous.attrib3, ";
$sel_ad .= "ad_data.ous_attrib4 = ad_ous.attrib4";
mysqli_query($con,$sel_ad);

// Copy data from ad_ous.group1 to ad_data.master_group1
// This section depends on ad_data.master_group1 to be populated by the section where ad_data joins ad_ous
// This section is needed for move.bat
$sel_ad_master_group1 = "UPDATE ad_data INNER JOIN ad_ous ON ad_data.master_ou = ad_ous.ou SET ";
$sel_ad_master_group1 .= "ad_data.master_group1 = ad_ous.group1, ";
$sel_ad_master_group1 .= "ad_data.master_script = ad_ous.script, ";
$sel_ad_master_group1 .= "ad_data.master_storage_path = ad_ous.storage_path, ";
$sel_ad_master_group1 .= "ad_data.master_drive_letter = ad_ous.drive_letter, ";
$sel_ad_master_group1 .= "ad_data.master_server_name = ad_ous.server_name, ";
$sel_ad_master_group1 .= "ad_data.master_user_share = ad_ous.user_share, ";
$sel_ad_master_group1 .= "ad_data.master_dn = ad_ous.dn";
mysqli_query($con,$sel_ad_master_group1);

//Copy data from ad_data_master table to ad_disabled
$sel_master_to_disabled = "UPDATE ad_disabled INNER JOIN ad_master_data ON ad_disabled.accountid = ad_master_data.accountid SET ";
$sel_master_to_disabled .= "ad_disabled.master_ou = ad_master_data.ou, ";
$sel_master_to_disabled .= "ad_disabled.master_first_name = ad_master_data.first_name, ";
$sel_master_to_disabled .= "ad_disabled.master_last_name = ad_master_data.last_name, ";
$sel_master_to_disabled .= "ad_disabled.master_attrib1 = ad_master_data.attrib1, ";
$sel_master_to_disabled .= "ad_disabled.master_attrib2 = ad_master_data.attrib2, ";
$sel_master_to_disabled .= "ad_disabled.master_attrib3 = ad_master_data.attrib3, ";
$sel_master_to_disabled .= "ad_disabled.master_attrib4 = ad_master_data.attrib4";
mysqli_query($con,$sel_master_to_disabled);

//Copy data from ad_disabled table to ad_master_data
$sel_disabled_to_master = "UPDATE ad_master_data INNER JOIN ad_disabled ON ad_master_data.accountid = ad_disabled.accountid SET ";
$sel_disabled_to_master .= "ad_master_data.disabled_attrib1 = ad_disabled.attrib1, ";
$sel_disabled_to_master .= "ad_master_data.disabled_attrib2 = ad_disabled.attrib2";
mysqli_query($con,$sel_disabled_to_master);

/////////////////////////////////////////Determine which accounts to create, move, disable, or enable//////////////

//Disable - From ad_data table
//This selection puts a 1 in ad_data.account_match if there is a match between ad_data.accountid and ad_master_data.accountid.
//Any record with a value of 1 ad_data.account_match will be left alone, and any record with a 0 will be disabled.
$sel_disable = "UPDATE ad_data INNER JOIN ad_master_data ON ad_data.accountid = ad_master_data.accountid SET ";
$sel_disable .= "ad_data.match_account = 1";
mysqli_query($con,$sel_disable);

//Create - From ad_master_data table
//This selection puts a 1 in ad_master_data.account_match if there is a match between ad_master_data.accountid and ad_data.accountid.
//Any record with a value of 1 in ad_master_data.account_match will be left alone, and any record with a 0 will be created.
//unless the reenable selection puts a 1 in ad_master_data.match_disabled_account. Then, the account will be reenabled and moved to the proper OU
$sel_create = "UPDATE ad_master_data INNER JOIN ad_data ON ad_master_data.accountid = ad_data.accountid SET ";
$sel_create .= "ad_master_data.match_account = 1";
mysqli_query($con,$sel_create);

//Move - From ad_data table
//This selection puts a 1 in ad_data.match_move_account for any account where there is a 1 in match_account and ou is not equal to master_ou.
//Accounts with a 1 in ad_data.match_move_account will be moved to the OU specified in master_ou
$sel_move = "UPDATE ad_data SET match_move_account = 1 WHERE match_account = 1 and ou != master_ou";
mysqli_query($con,$sel_move);

//Reenable - From ad_master_data table
//This selection puts a 1 in ad_master_data.match_disable_account for any record that exists in ad_master_data and ad_disabled
//Any record with a 1 in ad_master_data.match_disabled_account needs to be reenabled rather than created.
$sel_disable = "UPDATE ad_master_data INNER JOIN ad_disabled ON ad_master_data.accountid = ad_disabled.accountid SET ";
$sel_disable .= "ad_master_data.match_disabled_account = 1";
mysqli_query($con,$sel_disable);

//////////////////////////////////////////////////////Export Data//////////////////////////////////////////////////

//Export users to disable

    $disableArr['A'] = "accountid";
    $disableArr['B'] = "ous_dn";
    $disableArr['C'] = "ous_group1";

    $disable_file = fopen($iter_path . "/ad_disable.txt", "w") or die("Unable to open file!");
    $sel_ex_disable = mysqli_query($con,"SELECT * FROM ad_data WHERE match_account = 0");
    
    if(mysqli_num_rows($sel_ex_disable) > $max_disable){echo "FAIL! There are " . mysqli_num_rows($sel_ex_disable) . " records to disable.";}
    
    while($rec = mysqli_fetch_array($sel_ex_disable))
    {
        $fields = "";
        foreach($disableArr as $val)
        {
            $fields .= $rec[$val] . "^";
        }
        $fields .= "\n";
    
        fwrite($disable_file, $fields);
    }
    fclose($disable_file);

///// Export users to create

    $createArr['A'] = "accountid";
    $createArr['B'] = "ous_dn";
    $createArr['C'] = "first_name";
    $createArr['D'] = "last_name";
    $createArr['E'] = "ous_group1";
    $createArr['F'] = "ous_script";
    $createArr['G'] = "ous_storage_path";
    $createArr['H'] = "ous_drive_letter";
    $createArr['I'] = "ous_server_name";
    $createArr['J'] = "ous_user_share";
    
    $create_file = fopen($iter_path . "/ad_create.txt", "w") or die("Unable to open file!");
    $sel_ex_create = mysqli_query($con,"SELECT * FROM ad_master_data WHERE match_account = 0 AND match_disabled_account = 0");
    
    if(mysqli_num_rows($sel_ex_create) > $max_create){echo "FAIL! There are " . mysqli_num_rows($sel_ex_create) . " records to create.";}
    
    while($rec = mysqli_fetch_array($sel_ex_create))
    {
        $fields = "";
        foreach($createArr as $val)
        {
            $fields .= $rec[$val] . "^";
        }
        $fields .= "\n";
    
        fwrite($create_file, $fields);
    }
    fclose($create_file);

///// Export users to move

    $moveArr['A'] = "accountid";
    $moveArr['B'] = "master_dn";
    $moveArr['C'] = "ous_group1";
    $moveArr['D'] = "master_group1";
    $moveArr['E'] = "master_script";
    $moveArr['F'] = "master_storage_path";
    $moveArr['G'] = "master_drive_letter";
    $moveArr['H'] = "master_server_name";
    $moveArr['I'] = "master_user_share";
    $moveArr['J'] = "ous_dn";

    $move_file = fopen($iter_path . "/ad_move.txt", "w") or die("Unable to open file!");
    $sel_ex_move = mysqli_query($con,"SELECT * FROM ad_data WHERE match_move_account = 1");
    
    if(mysqli_num_rows($sel_ex_move) > $max_move){echo "FAIL! There are " . mysqli_num_rows($sel_ex_move) . " records to move.";}
    
    while($rec = mysqli_fetch_array($sel_ex_move))
    {
        $fields = "";
        foreach($moveArr as $val)
        {
            $fields .= $rec[$val] . "^";
        }
        $fields .= "\n";
    
        fwrite($move_file, $fields);
    }
    fclose($move_file);

/////Export users to reenable

    $enableArr['A'] = "accountid";
    $enableArr['B'] = "ous_dn";
    $enableArr['C'] = "ous_group1";
    $enableArr['D'] = "ous_script";
    $enableArr['E'] = "ous_storage_path";
    $enableArr['F'] = "ous_drive_letter";
    $enableArr['G'] = "ous_server_name";
    $enableArr['H'] = "ous_user_share";

    $enable_file = fopen($iter_path . "/ad_enable.txt", "w") or die("Unable to open file!");
    $sel_ex_enable = mysqli_query($con,"SELECT * FROM ad_master_data WHERE match_disabled_account = 1");
    
    if(mysqli_num_rows($sel_ex_enable) > $max_enable){echo "FAIL! There are " . mysqli_num_rows($sel_ex_enable) . " records to enable.";}
    
    while($rec = mysqli_fetch_array($sel_ex_enable))
    {
        $fields = "";
        foreach($enableArr as $val)
        {
            $fields .= $rec[$val] . "^";
        }
        $fields .= "\n";
        fwrite($enable_file, $fields);
    }
    fclose($enable_file);

mysqli_close($con);

?>