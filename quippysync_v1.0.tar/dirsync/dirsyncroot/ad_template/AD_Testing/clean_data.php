<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

// Make connection to the database
$mysql_con = $argv[1];
include($mysql_con);

//Remove special characters from the ad_master_data.last_name for matching
    mysqli_query($con,"UPDATE ad_master_data SET last_name = REPLACE(last_name,'\'','')");
    mysqli_query($con,"UPDATE ad_master_data SET last_name = REPLACE(last_name,' ','')");
    mysqli_query($con,"UPDATE ad_master_data SET last_name = REPLACE(last_name,'.','')");
    mysqli_query($con,"UPDATE ad_master_data SET last_name = REPLACE(last_name,'-','')");
    mysqli_query($con,"UPDATE ad_master_data SET last_name = LCASE(last_name)");

//Remove special characters from the ad_data.last_name for matching
    mysqli_query($con,"UPDATE ad_data SET last_name = REPLACE(last_name,'\'','')");
    mysqli_query($con,"UPDATE ad_data SET last_name = REPLACE(last_name,' ','')");
    mysqli_query($con,"UPDATE ad_data SET last_name = REPLACE(last_name,'.','')");
    mysqli_query($con,"UPDATE ad_data SET last_name = REPLACE(last_name,'-','')");
    mysqli_query($con,"UPDATE ad_data SET last_name = LCASE(last_name)");
    
// Remove trailing spaces from ad_master_data.accountid
    mysqli_query($con,"UPDATE ad_all_users SET accountid = REPLACE(accountid,'\r','')");
    mysqli_query($con,"UPDATE ad_all_users SET accountid = REPLACE(accountid,'\t','')");
    mysqli_query($con,"UPDATE ad_all_users SET accountid = REPLACE(accountid,'\n','')");

// Remove machine accounts
    mysqli_query($con,"DELETE FROM ad_all_users WHERE accountid LIKE '%$'");

// Set accountid to lowercase
    mysqli_query($con,"UPDATE ad_all_users SET accountid = LCASE(accountid)");

// Close the connection to the database
mysqli_close($con);

?>