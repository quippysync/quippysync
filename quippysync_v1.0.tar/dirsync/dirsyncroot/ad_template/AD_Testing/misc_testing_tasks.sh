#!/bin/bash

#     Copyright 2015 Anthony Tranquillo

#     This file is part of Quippysync.

#    Quippysync is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Quippysync is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Clear ad_all_users
    $php_path ./dirsyncroot/$iter/AD_Testing/clear_db.php $mysql_con 1>> $iter_path/php.log 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: call to $iter/AD_Testing/clear_db.php" "FAIL: call to $iter/AD_Testing/clear_db.php" 2;
        checkLog "php" "FAIL: Error in $iter/AD_Testing/clear_db.php" 10;

# Get import
    $mysql_import_path --columns=dn,accountid --fields-terminated-by=, --fields-optionally-enclosed-by=\" --local -u $mysql_user -p$mysql_password $iter "$iter_path/ad_all_users.csv";   
        reportStatus $? "bash" "bash" "SUCCESS: Import ad_all_users.csv" "FAIL: Import ad_all_users.csv" 2;
        checkLog "php" "FAIL: Error importing all users" 10;
    
# Clean Data
    $php_path ./dirsyncroot/$iter/AD_Testing/clean_data.php $mysql_con 1>> $iter_path/php.log 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: call to $iter/AD_Testing/clean_data.php" "FAIL: call to $iter/AD_Testing/clean_data.php" 2;
        checkLog "php" "FAIL: Error in $iter/AD_Testing/clean_data.php" 10;
    
# Set character encoding
    if [ "$set_ad_charenc" == "y" ]
    then
        file -bi $iter_path/ad_master_data.txt > temp;
        charenc=$(<temp);rm temp;
        $php_path ./dirsyncroot/$iter/AD_Testing/set_ad_charenc.php $mysql_con "$charenc" 1>> $iter_path/php.log 2>> $iter_path/php.log;
            checkLog "php" "FAIL: Error in set_ad_charenc.php" 10;
            reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Testing/set_ad_charenc.php" "FAIL: Call $iter/AD_Testing/set_ad_charenc.php" 2;
    fi


