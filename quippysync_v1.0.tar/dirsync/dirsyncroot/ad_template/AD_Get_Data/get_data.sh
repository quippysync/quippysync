#!/bin/bash
    
#     Copyright 2015 Anthony Tranquillo

#     This file is part of Quippysync.

#    Quippysync is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Quippysync is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.
    
# Clear the database
    $php_path ./dirsyncroot/$iter/AD_Get_Data/clear_db.php $mysql_con 1>> $iter_path/php.log 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Get_Data/clear_db.php" "FAIL: Call $iter/AD_Get_Data/clear_db.php" 1>> $iter_path/php.log 2>> $iter_path/php.log;
        checkLog "php" "FAIL: Error clearing the database" 10;
    
# Copy Master data to $iter_path
    cp "$root_directory/Repo/$iter/$master_data_file" "$iter_path/ad_master_data.txt" 2>> $iter_path/bash.log

# Copy AD data to $iter_path
    cp "$root_directory/Repo/$iter/ad_data/ad_data.csv" "$iter_path/ad_data.csv" 2>> $iter_path/bash.log
    cp "$root_directory/Repo/$iter/ad_data/ad_disabled.csv" "$iter_path/ad_disabled.csv" 2>> $iter_path/bash.log
    cp "$root_directory/Repo/$iter/ad_data/ad_ou_exemptions.csv" "$iter_path/ad_ou_exemptions.csv" 2>> $iter_path/bash.log
    
# Copy ad_all_users if testing    
    if [ "$testing" == "y" ]
    then
        cp "$root_directory/Repo/$iter/ad_data/ad_all_users.csv" "$iter_path/ad_all_users.csv" 2>> $iter_path/bash.log
    fi
        
# Make sure the master data is properly formatted.
    while read i; do
        sep=`grep -o "$ad_master_separator" <<<"$i" | wc -l`;
        if [ $sep != $ad_master_num_separators ]
        then reportStatus 1 "bash" "bash" "FAIL: Wrong number of separators in $i" "FAIL: Wrong number of separators in $i" 2;
        fi
    done < $iter_path/ad_master_data.txt
    
# Make sure master data's character encoding is correct
    if [ "$set_ad_charenc" != "y" ]
    then
        file -bi $iter_path/ad_master_data.txt > temp;charenc=$(<temp);rm temp;
        if [ "$charenc" != "$ad_charenc" ]
            then reportStatus 1 "bash" "bash" "FAIL: Wrong character encoding" "FAIL: Wrong character encoding" 2;
        fi
    fi
    
# Check the date on the master data file
    stat -c %Y ./Repo/$iter/$master_data_file > temp1.txt;master_file_time=$(<temp1.txt);rm temp1.txt;
    yesterday=$((`date +"%s"` - 86400));
    if [ "$master_file_time" -lt "$yesterday" ]
    	then reportStatus 1 "bash" "bash" "FAIL: Wrong date on master data file" "FAIL: Wrong date on master data file" 2;
    fi
    
# Import AD data into database
    
    # Import AD Master Data
    $mysql_import_path --columns=$ad_master_attrib_string --fields-terminated-by=, --local -u $mysql_user -p$mysql_password $mysql_db "$iter_path/ad_master_data.txt";
        reportStatus $? "bash" "bash" "SUCCESS: ad_master_data import" "FAIL: ad_master_data import" 2;
        checkLog "php" "FAIL! Error importing to ad_master_data" 10;
    
    # Import AD Data
    $mysql_import_path --columns=$ad_data_attrib_string --fields-terminated-by=, --fields-optionally-enclosed-by=\" --local -u $mysql_user -p$mysql_password $mysql_db "$iter_path/ad_data.csv";
        reportStatus $? "bash" "bash" "SUCCESS: ad_data import" "FAIL: ad_data import" 2;
        checkLog "php" "FAIL: Error importing to ad_data" 10;
    
    # Import AD Disabled
    $mysql_import_path --columns=$ad_disabled_attrib_string --fields-terminated-by=, --fields-optionally-enclosed-by=\" --local -u $mysql_user -p$mysql_password $mysql_db "$iter_path/ad_disabled.csv";
        reportStatus $? "bash" "bash" "SUCCESS: ad_disabled import" "FAIL: ad_disabed import" 2;
        checkLog "php" "FAIL: Error importing to ad_disabled" 10;
    
    # Import AD Exempt
    $mysql_import_path --columns=$ad_ous_exemptions_attrib_string --fields-terminated-by=, --fields-optionally-enclosed-by=\" --local -u $mysql_user -p$mysql_password $mysql_db "$iter_path/ad_ou_exemptions.csv";
        reportStatus $? "bash" "bash" "SUCCESS: ad_ou_exemptions import" "FAIL: ad_ou_exemptions import" 2;
        checkLog "php" "FAIL: Error importing to ad_ou_exemptions" 10;


#--fields-enclosed-by=name 
#                    Fields in the import file are enclosed by the given
#                    character.
#--fields-optionally-enclosed-by=name 
#                    Fields in the input file are optionally enclosed by the
#                    given character.
#--fields-escaped-by=name 
#                    Fields in the input file are escaped by the given
#                    character.
#--lines-terminated-by=name 
#                    Lines in the input file are terminated by the given
#                    string.
#--ignore-lines=#    Ignore first n lines of data infile.