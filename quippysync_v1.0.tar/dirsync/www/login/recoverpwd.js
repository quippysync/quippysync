//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function recover()
{
    var email = document.getElementById('recoverusername').value;
    var params = "email=" + email;
    sendParams(params,"recoverpwd.php",recoverResponse);   
}

function recoverResponse()
{
    var response = xmlHttp.responseText;
    if(eval(response) == 0)
    {
        document.getElementById('responsediv2').innerHTML = "There has already been two or more recovery attempts for the specified email with in the last 24 hours. Please try again tomorrow morning.";
    }
    else if(eval(response) == 1)
    {
        document.getElementById('responsediv2').innerHTML = "If the specified email is registered with an account on this server, you will receive a new password via email.";
    }
    else
    {
       document.getElementById('responsediv2').innerHTML = "Unknown login error."; 
    }
}