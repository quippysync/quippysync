<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("/var/local/dirsync/Cons/inc-con.php");

$email = base64_encode(strtolower($_POST['email']));

// Make sure the user has not tried to recover a password for the specified email in the last 24 hours.
$lockoutSel = mysqli_query($con,"SELECT id FROM recovery_attempts WHERE email = '$email'");  
if(mysqli_num_rows($lockoutSel) > 1)
{
	mysqli_close($con);
	echo 0;
	exit();
}
else
{
    $time = time();
    mysqli_query($con,"INSERT INTO recovery_attempts (email, timestamp) VALUES ('$email', '$time') ");     
}

// Send email if it is in the users table
$userSel = mysqli_query($con,"SELECT * FROM users WHERE username = '$email'");
if(mysqli_num_rows($userSel) > 0)
{
		include("../common/inc-genPwd.php");
		$newpwd = generatePwd();
		$newpwdEnc = sha1($newpwd);
		mysqli_query($con,"UPDATE users SET password = '$newpwdEnc' WHERE username = '$email' and admin != 1");

		$subject = "Dirsync Password Recovery";
		$message = "Your new password is " . $newpwd;
		$from = "From: Dirsync Administrator";
		$email = $_POST['email'];
		mail($email,$subject,$message,$from);
}

echo 1;

mysqli_close($con);


?>