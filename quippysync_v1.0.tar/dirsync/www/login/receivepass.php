<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

session_start();

//////////////////////OPTIONS/////////////////////////////////////////////////////////////////////
$secValid = 43200; //Number of seconds for which a session is valid.
$maxAttempts = 6; //Number of attempts allowed.

//////////////////////////////////////////////////////////////////////////////////////////////////
   
include("/var/local/dirsync/Cons/inc-con.php");
include("../common/inc-genID.php");

$username = base64_encode(strtolower($_POST['username']));
$password = sha1($_POST['password']);

// Make sure someone is not trying to brute force a username

$lockoutSel = mysqli_query($con,"SELECT lockout FROM users WHERE username = '$username'"); //This section is to stop them from trying to login again if their account has been deactivated. 
if(mysqli_num_rows($lockoutSel) > 0)
{
    $lockoutInfo = mysqli_fetch_array($lockoutSel);
    $numbAttempts = $lockoutInfo['lockout'];
    if($numbAttempts >= $maxAttempts)
    {
	mysqli_close($con);
	echo 2;
	exit();
    }
    else
    {
	mysqli_query($con,"UPDATE users SET lockout = " . ($numbAttempts + 1) . " WHERE username = '$username'");
    }
}

// Test the user's credentials and log them in if they are right
$userSel = mysqli_query($con,"SELECT * FROM users WHERE username = '$username' and password = '$password'");
if(mysqli_num_rows($userSel) == 1)
{
    $userInfo = mysqli_fetch_array($userSel);
    $userNumb = $userInfo['autonumber'];

    $sessionid = generateID();
    $timestamp = (time() + $secValid); //Sessions are valid for 12 hours
    mysqli_query($con,"UPDATE users SET sessionid = '$sessionid' WHERE autonumber = '$userNumb'");     
    mysqli_query($con,"UPDATE users SET timestamp = '$timestamp' WHERE autonumber = '$userNumb'");     
    mysqli_query($con,"UPDATE users SET lockout = 0 WHERE autonumber = '$userNumb'");
        
    $_SESSION['dsessionid'] = $sessionid;
    $_SESSION['duserid'] = $userNumb;
    $_SESSION['dfirstname'] = $userInfo['firstname'];
    $_SESSION['dlastname'] = $userInfo['lastname'];
    $_SESSION['ddomain'] = "";
	$_SESSION['diteration'] = 0;

    echo 1;
}
else
{
    echo 0;
}

mysqli_close($con);


?>