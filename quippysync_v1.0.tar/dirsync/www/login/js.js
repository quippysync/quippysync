//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function showAgreement()
{    
    document.getElementById('agreementdiv').style.top = ctrPopH(450);
    document.getElementById('agreementdiv').style.left = ctrPopW(600);
    document.getElementById('agreementdiv').style.visibility = "visible";
}

function hideAgreement()
{
    document.getElementById('agreementdiv').style.visibility = "hidden";
}

function ctrPopW(divWidth)
{
    var leftPos = eval(window.pageXOffset + 0.5*window.innerWidth - 0.5*divWidth);
    return leftPos + "px";
}

function ctrPopH(divHeight)
{
    var topPos = eval(window.pageYOffset + 0.5*window.innerHeight - 0.5*divHeight);
    return topPos + "px";
}