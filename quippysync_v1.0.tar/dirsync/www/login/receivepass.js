//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function login()
{
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var params = "username=" + username + "&password=" + encodeURIComponent(password);
    sendParams(params,"receivepass.php",loginResponse);   
}

function loginResponse()
{
    var response = xmlHttp.responseText;
    
    if(eval(response) == 1)
    {
        window.location = "../home/index.php?table=na&page=13";
    }
    else if(eval(response) == 0)
    {
        document.getElementById('responsediv').innerHTML = "Login credentials incorrect.";
    }
    else if(eval(response) == 2)
    {
        document.getElementById('responsediv').innerHTML = "There were too many login attempts on this account. Try back at the end of the hour.";
    }
    else
    {
       document.getElementById('responsediv').innerHTML = "Unknown login error."; 
    }
}