<?php
session_start();

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.


include("../common/inc-con.php");
?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<title>Directory Sync Home</title>
<link rel='stylesheet' type='text/css' href='css.css'></link>
<script src='js.js' type='text/javascript'></script>
<script src='setdomain.js' type='text/javascript'></script>
<script src='deldomain.js' type='text/javascript'></script>
<script src='adddomain.js' type='text/javascript'></script>
<script src='../common/ajax.js' type='text/javascript'></script>
<script src='../common/rep_rest_chars.js' type='text/javascript'></script>
<script src='../common/valobjects.js' type='text/javascript'></script>

</head><body><div id='maindiv'>
<p>&nbsp;</p>
<p>&nbsp;</p>

<?php include("../common/inc-nav.php"); ?>
<table>
    <tr>
        <td class='right'>Database: </td>
        <td><input type='text' id='database' /></td>
    </tr>
    <tr>
        <td class='right'>Type: </td>
        <td>
            <select id='type'>
                <option value='1'>AD</option>
                <option value='2'>Other</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td class='right'>&nbsp;</td>
        <td><input type='button' value='Add' onclick='addDomain();' /></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
    
</table>

<table id='maintable'>
<tr>
    <th>Database</th>
    <th>Type</th>
    <th>Set</th>
    <th>Delete</th>
</tr>

<?php

$typeArr[0] = "None";
$typeArr[1] = "AD";
$typeArr[2] = "Other";

$sel = mysqli_query($con,"SELECT * FROM domains");
while($rec = mysqli_fetch_array($sel))
{
    echo "<tr>";
    
    echo "<td class='border'>" . $rec['db'] . "</td>";
    echo "<td class='border'>" . $typeArr[$rec['type']] . "</td>";
    echo "<td class='border'><input type='button' value='Set' onclick='setDomain(\"" . $rec['db'] . "\"," . $rec['type'] . ",this);' /></td>";
    echo "<td class='border'><input type='button' value='Delete' onclick='delDomain(" . $rec['id'] . ",this);' /></td>";

    echo "</tr>";
}

mysqli_close($con);

?>
 
</table>

<div id='responsediv'>You are not editing <?php if($_SESSION['ddb']){echo $_SESSION['ddb'];}else{echo "NA";} ?></div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    
</div></body></html>