//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function delDomain(recid,el)
{
    elCache = el;
    if (confirm("Are you sure you want to delete this record?") == true)
    {
        UIP = 1;
        var params = "id=" + recid;
        sendParams(params,"deldomain.php",delResponse);
    }
    else
    {
        alert("Delete canceled!");
    }
}

function delResponse()
{
    var response = xmlHttp.responseText;
    if(eval(response) == 1)
    {
        document.getElementById('maintable').deleteRow(elCache.parentNode.parentNode.rowIndex);
    }
    else
    {
        alert("There was a problem deleting the domain.");
    }

    UIP = 0
}