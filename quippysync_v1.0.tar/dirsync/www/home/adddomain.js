//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function addDomain(db,type)
{
    dbCache = document.getElementById('database').value;
    typeCache = document.getElementById('type').value;
    
    if (UIP == 0)
    {
        if(validateAdd())
        {
            UIP = 1;
            var params = "db=" + dbCache + "&type=" + typeCache;        
            sendParams(params,"adddomain.php",addDomainResponse);
        }
    }
    else
    {
        alert("Finish updating the item!");
    }
}

function addDomainResponse()
{
    var response = xmlHttp.responseText;
    if(eval(response) > 0)
    {
        var newRow = document.getElementById('maintable').insertRow(-1);
       
        //Create cells in new row
        var cell1 = newRow.insertCell(0);
        var cell2 = newRow.insertCell(1);
        var cell3 = newRow.insertCell(2);
        var cell4 = newRow.insertCell(3);
        
        ////Put content in cells
        cell1.innerHTML = dbCache;
        cell2.innerHTML = typeArr[typeCache];
        cell3.innerHTML = "<input type='button' value='Set' onclick='setDomain(\"" + dbCache + "\"," + typeCache + ",this);' />";
        cell4.innerHTML = "<input type='button' value='Delete' onclick='delDomain(" + response + ",this);' />";
    
        cell1.setAttribute("class","border");
        cell2.setAttribute("class","border");
        cell3.setAttribute("class","border");
        cell4.setAttribute("class","border");
        
        document.getElementById('database').value = "";
    }
    else
    {
        alert("There was an error adding the domain");
    }

    UIP = 0
}

function validateAdd()
{
    if(!domainObj.exec(dbCache))
    {
      alert(domainMsg);
      return false;
    }
    else
    {
        return true;
    }
}