<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function generateID()
{
$numb1 = rand(97,122);
$numb2 = rand(97,122);
$numb3 = rand(65,90);
$numb4 = rand(97,122);
$numb5 = rand(48,57);
$numb6 = rand(97,122);
$numb7 = rand(97,122);
$numb8 = rand(97,122);
$numb9 = rand(65,90);
$numb10 = rand(97,122);
$numb11 = rand(97,122);
$numb12 = rand(97,122);
$numb13 = rand(65,90);
$numb14 = rand(97,122);
$numb15 = rand(97,122);
$numb16 = rand(65,90);
$numb17 = rand(65,90);
$numb18 = rand(97,122);
$numb19 = rand(97,122);
$numb20 = rand(48,57);
$numb21 = rand(97,122);
$numb22 = rand(97,122);
$numb23 = rand(65,90);
$numb24 = rand(97,122);
$numb25 = rand(48,57);
$numb26 = rand(97,122);
$numb27 = rand(65,90);
$numb28 = rand(97,122);
$numb29 = rand(97,122);
$numb30 = rand(97,122);
$numb31 = rand(48,57);
$numb32 = rand(97,122);

$id756 = chr($numb1) . chr($numb2) . chr($numb3) . chr($numb4) . chr($numb5) . 
chr($numb6) . chr($numb7) . chr($numb8) . chr($numb9) . chr($numb10) . 
chr($numb11) . chr($numb12) . chr($numb13) . chr($numb14) . chr($numb15) . 
chr($numb16) . chr($numb17) . chr($numb18) . chr($numb19) . chr($numb20) . 
chr($numb21) . chr($numb22) . chr($numb23) . chr($numb24) . chr($numb25) . 
chr($numb26) . chr($numb27) . chr($numb28) . chr($numb29) . chr($numb30) . 
chr($numb31) . chr($numb32);
return $id756;
}
?>