//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.


//To use the sendParams function, use the following syntax: sendParams(params,script,returnFunction);

var xmlHttp = createXmlHttpRequestObject();
var returnFunc; //The function to which the response should be returned.

function createXmlHttpRequestObject() 
{
  var xmlHttp;
  try
  {
    xmlHttp = new XMLHttpRequest();
  }
  catch(e)
  {
    var XmlHttpVersions = new Array("MSXML2.XMLHTTP.6.0",
                                    "MSXML2.XMLHTTP.5.0",
                                    "MSXML2.XMLHTTP.4.0",
                                    "MSXML2.XMLHTTP.3.0",
                                    "MSXML2.XMLHTTP",
                                    "Microsoft.XMLHTTP");
    for (var i=0; i<XmlHttpVersions.length && !xmlHttp; i++) 
    {
      try 
      { 
        xmlHttp = new ActiveXObject(XmlHttpVersions[i]);
      } 
      catch (e) {}
    }
  }
  if (!xmlHttp)
    alert("Error creating the XMLHttpRequest object.");
  else 
    return xmlHttp;
}

//////////////////////////////////////////////////////////////////////////////////////////////
function sendParams(params,sendScript,returnFunction)
{
    returnFunc = returnFunction;
    if (xmlHttp)
    {
        try
        {
        xmlHttp.open("POST",sendScript,true);
          
        xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlHttp.setRequestHeader("Content-length", params.length);
        xmlHttp.setRequestHeader("Connection", "close");

        xmlHttp.onreadystatechange = handleStateChange1;
        xmlHttp.send(params);
        }
        catch (e)
        {
        alert("Can't connect to server:\n" + e.toString());
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////////
function handleStateChange1() 
{
  if (xmlHttp.readyState == 4) 
  {
    if (xmlHttp.status == 200) 
    {
      try
      {
        returnFunc();
      }
      catch(e)
      {
        alert("Error reading the response: " + e.toString());
      }
    } 
    else
    {
      alert("There was a problem retrieving the data:\n" + xmlHttp.statusText);
    }
  }
}