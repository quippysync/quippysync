<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function generatePwd()
{
$numb1 = rand(97,122);
$numb2 = rand(97,122);
$numb3 = rand(65,90);
$numb4 = rand(97,122);
$numb5 = rand(48,57);
$numb6 = rand(97,122);
$numb7 = rand(97,122);
$numb8 = rand(97,122);
$numb9 = rand(65,90);
$numb10 = rand(97,122);

$id756 = chr($numb1) . chr($numb2) . chr($numb3) . chr($numb4) . chr($numb5) . 
chr($numb6) . chr($numb7) . chr($numb8) . chr($numb9) . chr($numb10);

return $id756;
}
?>