<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function repChar($str)
{
$str = str_replace("\\","^3]",$str);
$str = str_replace("'","^4]",$str);
return $str;
}

// Excapes back slashes and single quotes. Used for querying the DB if there are single quotes or back slashes stored in the DB
function escSQ_Slash($str)
{
$str = str_replace("\\","\\\\",$str);
$str = str_replace("'","\'",$str);
return $str;
}

?>