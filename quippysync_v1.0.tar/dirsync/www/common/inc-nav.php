<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

$table = $_GET['table'];
$page = $_GET['page'];

echo "<script type='text/javascript'>var table='$table';var page='$page';</script>";

if($_SESSION['ddomaintype'] == 1)
{
    $navArr['AD OUs'] = "../ad_ous/index.php?table=na&page=1";
    $navArr['AD Options'] = "../options/index.php?table=2&page=2";
    $navArr['AD OU Exemptions'] = "../exemptions/index.php?table=0&page=3";
    $navArr['AD User Exemptions'] = "../exemptions/index.php?table=1&page=4";
    $navArr['AD Testing'] = "../ad_testing/index.php?table=1&page=5";
    $navArr['AD Cleaning'] = "../ad_cleaning/index.php?table=1&page=6";
    $navArr['Logs'] = "../logs/index.php?table=na&page=7";
    $navArr['Users'] = "../users/index.php?table=na&page=8";
    $navArr['Home'] = "../home/index.php?table=na&page=9";
}
//elseif($_SESSION['ddomaintype'] == 2)
//{
//    $navArr['Google OUs'] = "../g_ous/index.php?table=na&page=1";
//    $navArr['Google Options'] = "../options/index.php?table=1&page=2";
//    $navArr['Google OU Exemptions'] = "../exemptions/index.php?table=2&page=3";
//    $navArr['Google User Exemptions'] = "../exemptions/index.php?table=3&page=4";
//    $navArr['Google Testing'] = "../g_testing/index.php?table=na&page=5";
//    $navArr['Google Cleaning'] = "../g_cleaning/index.php?table=0&page=6";
//    $navArr['Logs'] = "../logs/index.php?table=na&page=7";
//    $navArr['Users'] = "../users/index.php?table=na&page=8";
//    $navArr['Home'] = "../home/index.php?table=na&page=9";
//}
else
{
    $navArr['Logs'] = "../logs/index.php?table=na&page=1";
    $navArr['Users'] = "../users/index.php?table=na&page=2";
    $navArr['Home'] = "../home/index.php?table=na&page=3";
}

echo "<h3 id='title'>!</h3>";

echo "<table><tr><td style='width:499px'><select onchange='nav();' id='navselect'><option value='0'>Select an Option</option>";

$jsPageArr = "";
$jsTitleArr = "";
$counter = 1;
foreach($navArr as $key=>$val)
{
    echo "<option value='" . $val . "'>" . $key . "</option>";
    $jsTitleArr .= "titleArr['" . $counter . "'] = '$key';";
    $jsPageArr .= "pageArr['" . $counter . "'] = '$val';";
    $counter++;
}

echo "</select></td><td style='width:499px;text-align:right;'>Hey " . base64_decode($_SESSION['dfirstname']) . " " . base64_decode($_SESSION['dlastname']) . "! &nbsp;&nbsp; <a href='../login/index.php'>Logout</a></td></tr></table>";

echo "<script type='text/javascript'>var pageArr = new Array();";
echo $jsPageArr;
echo "</script>";

echo "<script type='text/javascript'>var titleArr = new Array();";
echo $jsTitleArr;
echo "</script>";

?>

<script type='text/javascript'>
    
    function nav()
    {
        var page1 = document.getElementById('navselect').value;

        if(page1 !== 0 && page1 !== "0")
        {
            window.location = page1;
        }
    }
    
    window.onload = function(){
        document.getElementById('navselect').value = pageArr[page];
        
        if(titleArr[page])
        {
            document.getElementById('title').innerHTML = titleArr[page];    
        }
        else
        {
            document.getElementById('title').innerHTML = 'Home';    
        }
    };    
</script>