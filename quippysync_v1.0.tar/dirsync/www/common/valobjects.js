//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

//////////////////////////////////////////////////////Options Validation Objects//////////////////////////////////////////////////////////////

// ~!@#$&*,()_{}|:"<>?`-=[]/;. aA1
var gDNObj= new RegExp(/^[0-9a-zA-Z\s\~\!\@\#\$\&\*\(\)\_\{\}\|\:\"\<\>\?\`\-\=\[\]\/\;\,\.]{1,50}$/);
var gDNMsg = "There is a problem with the DN field. It must contain between 1 and 50 characters. Allowed characters are numbers, letters, spaces and ~!@#$&*=,()_{}|:\"<>?`-[]/;.";

// ou=oua -._a,ou=sandbox,dc=tonytranquillo,dc=com
// The user must know not to include =  or , in the OU name.
var adDNObj= new RegExp(/^[0-9a-zA-Z\s\_\-\.\=\,]{1,100}$/);
var adDNMsg = "The DN field must contain between 1 and 100 characters. Only numbers, letters, spaces and the following characters are allowed: _-.=,";

// cn=group. ()_-a,ou=sandbox,dc=tonytranquillo,dc=com
// The user must know not to include =  or , in the OU name.
var adGrpObj= new RegExp(/^[0-9a-zA-Z\s\_\-\.\(\)\=\,]{0,100}$/);
var adGrpMsg = "The Group field must contain less than 100 characters. Only numbers, letters, spaces and the following characters are allowed: _-.()=,";

// aA1_-.'
// Note that this is also for Google groups
var gUserObj = new RegExp(/^[a-zA-Z0-9\_\-\.\']{1,25}$/);
var gUserMsg = "User and group names must contain between 1 and 25 characters. Only letters, numbers, and the following characters are allowed: _-.'";

// ~.()_`-' aA1
var adUserObj = new RegExp(/^[0-9a-zA-Z\s\~\.\(\)\_\`\-\']{1,35}$/);
var adUserMsg = "Usernames must contain between 1 and 35 characters. Only letters, numbers, spaces and the following characters are allowed: ~.()_`-'";

// a~ ()_-'.bat
var scriptObj = new RegExp(/^[0-9a-zA-Z\s\~\.\(\)\_\-\']{0,45}$/);
var scriptMsg = "The Script field must contain less than 45 characters. Only letters, numbers, spaces and the following are allowed: ~.()_-'";

// C:\~.!@$()_+{}`-[]'n aA1
var storage_pathObj = new RegExp(/^[0-9a-zA-Z\s\:\~\.\!\@\$\(\)\_\+\{\}\`\-\[\]\'\\]{0,200}$/);
var storage_pathMsg = "The Storage Path must contain less than 200 characters. Only letters, numbers, spaces, and the following are allowed: :~.!@$()_+{}`-[]'\\";

// A
var drive_letterObj = new RegExp(/^[A-Z]{0,1}$/);
var drive_letterMsg = "The drive letter field should only contain one capital letter.";

// -.Aa1
var server_nameObj = new RegExp(/^[0-9a-zA-Z\-\.]{0,50}$/);
var server_nameMsg = "The Server Name field must contain less than 50 characters. Only numbers, letters, hyphens and periods are allowed.";

// ~.$()_-' aA1
var user_shareObj = new RegExp(/^[0-9a-zA-Z\s\~\.\$\(\)\_\-\']{0,45}$/);
var user_shareMsg = "The User Share field must contain less than 45 characters. Only letters, numbers, spaces and the following are allowed: ~.$()_-'";

// a_b
var optionObj = new RegExp(/^[a-z\_]{1,50}$/);
var optionMsg = "There is a problem with the option field. It must have between 1 and 50 characters. Only lower case letters and underscores are allowed.";

// ~`^{}[]/$#@!%&*-_+=()<|>'":;?,.\ aA1
var valueObj = new RegExp(/^[0-9a-zA-Z\s\~\`\^\{\}\[\]\/\$\#\@\!\%\&\*\-\_\+\=\(\)\<\|\>\'\"\:\;\?\,\.\\]{1,1024}$/);
var valueMsg = "There is a problem with the value field. It must contain between 1 and 1,024 characters.";

//  ~`^{}[]/$#@!%&*-_+=()<|>'":;?,.\ aA1
var descriptionObj= new RegExp(/^[0-9a-zA-Z\s\~\`\^\{\}\[\]\/\$\#\@\!\%\&\*\-\_\+\=\(\)\<\|\>\'\"\:\;\?\,\.\\]{0,500}$/);
var descriptionMsg = "There is a problem with the description field. It must contain less than 500 characters.";

// ~`{}[]/$#@!%&*-_+=()<|>'":;?,. aA1
var attribObj= new RegExp(/^[0-9a-zA-Z\s\~\`\{\}\[\]\/\$\#\@\!\%\&\*\-\_\+\=\(\)\<\|\>\'\"\:\;\?\,\.]{0,500}$/);
var attribMsg = "There is a problem with one of the attribute fields. They must contain less than 500 characters and cannot contain ^.";

// a_A1
var ouObj = new RegExp(/^[a-zA-Z0-9\_]{1,20}$/);
var ouMsg = "There is a problem with the ou field. It must have between 1 and 20 characters. Only letters, numbers, and underscores are allowed.";

// a_A1
var domainObj = new RegExp(/^[a-zA-Z0-9\_]{1,35}$/);
var domainMsg = "There is a problem with the Database field. It must have between 1 and 35 characters. Only letters, numbers, and underscores are allowed.";

// aA1 -.'
var nameObj = new RegExp(/^[a-zA-Z0-9\s\-\.\']{1,25}$/);
var nameMsg = "Names must contain between 1 and 25 characters. Only letters, numbers, spaces, and the following characters are allowed: _-.'";

// tony@tonytranquillo.com
var emailObj = new RegExp(/^[a-zA-Z0-9\.\_\-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/);
var emailMsg = "That is not a valid email";

// ~`^{}[]/$#@!%&*-_+=()<|>'":;?,.\ aA1
var passwordObj = new RegExp(/^[0-9a-zA-Z\s\~\`\^\{\}\[\]\/\$\#\@\!\%\&\*\-\_\+\=\(\)\<\|\>\'\"\:\;\?\,\.\\]{6,24}$/);
var passwordMsg = "Passwords must be between 6 and 24 characters.";

// 20150127
var dateObj = new RegExp(/^[0-9]{8}$/);
var dateMsg = "Fields requesting a date should be 8 numbers in the format yyyymmdd.";

var allCharsObj= new RegExp(/^[0-9a-zA-Z\s\~\`\^\{\}\[\]\/\$\#\@\!\%\&\*\-\_\+\=\(\)\<\|\>\'\"\:\;\?\,\.\\]{0,1000}$/);
var allCharsMsg = "";
