<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

$iter = $_POST['iter'];

include("../../Cons/inc-" . $iter . ".php");

// Get accounts to move to exempt OUs
$moveBuffer = "";
$moveFile = fopen("../../Repo/" . $iter . "/ad_changedir/ad_move.txt", "w") or die("Unable to open file!1");
$moveSel = mysqli_query($con,"SELECT dn,change_to FROM ad_data WHERE exempt = 1 AND match_account = 0 AND change_to != ''");
while($rec = mysqli_fetch_array($moveSel))
{
    $moveBuffer .= $rec['dn'] . "^" . $rec['change_to'] . "\n";
}
fwrite($moveFile,$moveBuffer);
fclose($moveFile);

// Get accounts to rename
$renameBuffer = "";
$renameFile = fopen("../../Repo/" . $iter . "/ad_changedir/ad_rename.txt", "w") or die("Unable to open file!2");
$renameSel = mysqli_query($con,"SELECT accountid,change_to,ous_dn FROM ad_data WHERE exempt = 0 AND match_account = 0 AND change_to != ''");

while($rec = mysqli_fetch_array($renameSel))
{
    $renameBuffer .= $rec['accountid'] . "^" . $rec['change_to'] . "\n";
}
fwrite($renameFile,$renameBuffer);
fclose($renameFile);

mysqli_close($con);


?>