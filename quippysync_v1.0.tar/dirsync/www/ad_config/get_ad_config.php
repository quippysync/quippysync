<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

$iter = $_POST['iter'];
$create_exempt_users = $_POST['create_exempt_users'];

include("../../Cons/inc-" . $iter . ".php");

// Get AD OUs
$ouBuffer = "";
$ouFile = fopen("../../Repo/" . $iter . "/ad_config/ad_ous.txt", "w") or die("Unable to open file!1");
$ouSel = mysqli_query($con,"SELECT dn,ou FROM ad_ous WHERE include_in_export = 1");
while($rec = mysqli_fetch_array($ouSel))
{
    $ouBuffer .= $rec['ou'] . "^" . $rec['dn'] . "\n";
    
    // If testing create exempt users for OUs
    if($create_exempt_users == "y")
    {
        
        $exemption = $rec['ou'] . "-dummyuser";
        mysqli_query($con,"INSERT INTO exemptions (exemption, type) VALUES ('$exemption', '1')");
    }
}
fwrite($ouFile,$ouBuffer);
fclose($ouFile);

// Get AD Exempt OUs
$exemptBuffer = "";
$exemptFile = fopen("../../Repo/" . $iter . "/ad_config/ad_exempt_ous.txt", "w") or die("Unable to open file!2");
$exemptSel = mysqli_query($con,"SELECT exemption FROM exemptions WHERE type = 0");
$counter = 1;

while($rec = mysqli_fetch_array($exemptSel))
{
    $exemptBuffer .= $rec['exemption'] . "\n";
    
    // If testing, create a dummy user for each exempt OU
    
    if($create_exempt_users == "y")
    {
        $exemption = "exemption-dummyuser" . $counter;
        mysqli_query($con,"INSERT INTO exemptions (exemption, type) VALUES ('$exemption','1')");
    }
    
    $counter++;
}
fwrite($exemptFile,$exemptBuffer);
fclose($exemptFile);

// Create exemption for dummy user if necessary
    if($create_exempt_users == "y")
    {
        mysqli_query($con,"INSERT INTO exemptions (exemption, type) VALUES ('disabled-dummyuser','1')");
    } 

// Get AD Options
$optionsBuffer = "";
$optionsFile = fopen("../../Repo/" . $iter . "/ad_config/ad_options.bat", "w") or die("Unable to open file!3");
$optionsSel = mysqli_query($con,"SELECT options.option,value FROM options WHERE type = 2 AND (options.option = 'ad_disabled_ou' OR options.option = 'ad_fqdn_suffix' OR options.option = 'ad_email_suffix')");
while($rec = mysqli_fetch_array($optionsSel))
{
    $optionsBuffer .= "set " . $rec['option'] . "=" . $rec['value'] . "\n";
}
fwrite($optionsFile,$optionsBuffer);
fclose($optionsFile);

mysqli_close($con);

?>