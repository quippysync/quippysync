<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");

//$sel = "UPDATE ad_data INNER JOIN ad_master_data ON ad_data.temp6 = ad_master_data.temp6 SET ";
//$sel .= "ad_data.change_to = ad_master_data.accountid, ad_data.exempt = 0 WHERE ad_master_data.match_account = 0 AND ad_data." . $ad_data . " != ''";
//mysqli_query($con,$sel);


$ad_data = $_POST['ad_data'];
$ad_master_data = $_POST['ad_master_data'];

$sel = "UPDATE ad_data INNER JOIN ad_master_data ON ad_data." . $ad_data . " = ad_master_data." . $ad_master_data . " SET ";
$sel .= "ad_data.change_to = ad_master_data.accountid, ad_data.exempt = 0 WHERE ad_master_data.match_account = 0 AND ad_data." . $ad_data . " != ''";
mysqli_query($con,$sel);

$sel2 = "UPDATE ad_master_data INNER JOIN ad_data ON ad_master_data." . $ad_master_data . " = ad_data." . $ad_data . " SET ";
$sel2 .= "ad_master_data.match_account = 1 WHERE ad_master_data." . $ad_master_data . " != ''";
mysqli_query($con,$sel2);

mysqli_close($con);

header("location:index.php?table=na&page=" . $_POST['page']);

?>