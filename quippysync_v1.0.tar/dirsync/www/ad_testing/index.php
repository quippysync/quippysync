<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");
error_reporting(E_ALL & ~E_NOTICE);

?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<title>Common Options</title>
<link rel='stylesheet' type='text/css' href='css.css'></link>
<script src='js.js' type='text/javascript'></script>
<script src='initchange.js' type='text/javascript'></script>
<script src='change.js' type='text/javascript'></script>
<script src='nextpage.js' type='text/javascript'></script>
<script src='match_accounts.js' type='text/javascript'></script>
<script src='search.js' type='text/javascript'></script>
<script src='exempt.js' type='text/javascript'></script>
<script src='showexempt.js' type='text/javascript'></script>
<script src='../common/ajax.js' type='text/javascript'></script>
<script src='../common/rep_rest_chars.js' type='text/javascript'></script>
<script src='../common/valobjects.js' type='text/javascript'></script>

</head><body><div id='maindiv'>

<?php include("../common/inc-nav.php"); ?>

<table>
    <tr>
        <td><a href='javascript:void(0);' onclick='showMatch();'> Match by ID </a></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td><a href='javascript:void(0);' onclick='showSearch();'> Search DB </a></td>
    </tr>
</table>

<hr></hr>

<table id='userstable'>

<tr>
    <th>Username</th>
    <th>Last Name</th>
    <th>First Name</th>
    <th>OU</th>
    <th>Last Logon</th>
    <th>Change / Move</th>
    <th>Change</th>
</tr>
    
<?php

// Set the current page
if($_POST['current_page'] == null)
{
    $_POST['current_page'] = 0;
}
$current_page = $_POST['current_page'];    

// Set the max records per gage
if($_POST['max_records_per_page'] == null)
{
    $_POST['max_records_per_page'] = 100;
}
$max_records_per_page = $_POST['max_records_per_page'];    

$total_rec = mysqli_num_rows(mysqli_query($con,"SELECT id FROM ad_data WHERE match_account = 0"));
$num_pages = ceil($total_rec / $max_records_per_page);

$sel = mysqli_query($con,"SELECT * FROM ad_data WHERE match_account = 0 ORDER BY accountid LIMIT " . ($current_page * $max_records_per_page) . "," . $max_records_per_page . "");
while($rec = mysqli_fetch_array($sel))
{
    
    echo "<tr>";
    echo "<td class='border'>" . $rec['accountid'] . "</td>";
    echo "<td class='border'>" . $rec['last_name'] . "</td>";
    echo "<td class='border'>" . $rec['first_name'] . "</td>";
    echo "<td class='border'>" . $rec['ou'] . "</td>";
    echo "<td class='border'>" . substr($rec['last_logon'],0,10) . "</td>";
    
    if($rec['exempt'] == 0)
    {
        echo "<td class='border'>" . $rec['change_to'] . "</td>";
    }
    else
    {
        echo "<td class='border'><a href='javascript:void(0);' onclick='showExempt(" . $rec['id'] . ");'>Exempt</a></td>";
    }
    
    
    echo "<td class='border'><input type='button' value='Change' onclick='initChange(" . $rec['id'] . ",this)' /></td>";
    echo "</tr>";
}

?>

</table>

<!-- Make the page links -->
<p id='navdiv'> | 
<?php
for($i=0;$i<=($num_pages-1);$i++)
{
    if($current_page == $i)
    {
        echo ($i+1) . " | ";
    }
    else
    {
        echo "<a href='javascript:void(0);' onclick='nextPage(" . $i . ");' >" . ($i+1) . "</a> | ";
    }
}
?>
</p>

<!-- Set the records per page -->
<p>
<form action='index.php?table=na&page=<?php echo $page; ?>' method='post'>Records per page 
    <input type='text' value='<?php echo $max_records_per_page; ?>' name='max_records_per_page' id='max_records_per_page' style='width:3em;' /> 
    <input type='submit' value='Set' />
</form>
</p>

<!-- Next page form-->
<div>
<form action='index.php?table=na&page=<?php echo $page; ?>' id='nextpageform' method='post'>
    <input type='hidden' value='0' id='current_page' name='current_page' />
    <input type='hidden' value='<?php echo $max_records_per_page; ?>' name='max_records_per_page' /> 
</form>
</div>

<!--Response Div-->
<div id='response'></div>

<!-- ////////////////////////////////////// Change Div ///////////////////////////////////// -->
<div id='changediv'>
<h3>Change account name <span id='change_account_name'></span></h3>
    <table id='suggestionstable'>
        <tr>
            <th>Last Name</th>
            <th>First Name</th>
            <th>Username</th>
            <th>Choose</th>
        </tr>
    </table>
    
    <p>
        Change <span id='changefrom'></span> to <input type='text' id='changeto' />
        <input type='button' value='Change' onclick='change(this);' />
        <input type='button' value='Cancel' onclick='cancel();' />
    </p>
    
    <p>
        Move to
        <select id='exemptou'>
            <?php
            
                $sel2 = mysqli_query($con,"SELECT * FROM exemptions WHERE type = 0");
                while($rec2 = mysqli_fetch_array($sel2))
                {
                    echo "<option value='" . $rec2['exemption'] . "'>" . $rec2['exemption'] . "</option>";
                }
                
                mysqli_close($con);
            ?>
        </select>
        <input type='button' value='Move' onclick='exempt();' />
    </p>
</div>

<!-- ////////////////////////////////////////////// Match Div ////////////////////////////////// -->
<div id='matchdiv'>
<h3>Match Accounts</h3>
<form action='match_accounts.php' method='post'>
<table>
<tr>
    <td class='right'>ad_data.</td>
    <td>
        <select name='ad_data'>
        <option value='attrib1'>attrib1</option>
        <option value='attrib2'>attrib2</option>
        <option value='attrib3'>attrib3</option>
        <option value='attrib4'>attrib4</option>
        <option value='temp1'>temp1</option>
        <option value='temp2'>temp2</option>
        <option value='temp3'>temp3</option>
        <option value='temp4'>temp4</option>
        <option value='temp5'>temp5</option>
        <option value='temp6'>temp6</option>
        </select>
    </td>
</tr>
<tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
</tr>
<tr>
    <td class='right'>To</td>
    <td>&nbsp;</td>
</tr>

<tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
</tr>

<tr>
    <td class='right'>ad_master_data.</td>
    <td>
        <select name='ad_master_data'>
        <option value='attrib1'>attrib1</option>
        <option value='attrib2'>attrib2</option>
        <option value='attrib3'>attrib3</option>
        <option value='attrib4'>attrib4</option>
        <option value='temp1'>temp1</option>
        <option value='temp2'>temp2</option>
        <option value='temp3'>temp3</option>
        <option value='temp4'>temp4</option>
        <option value='temp5'>temp5</option>
        <option value='temp6'>temp6</option>
        </select>       
    </td>
</tr>
<tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
</tr>
<tr>
    <td class='right'><input type='button' value='Cancel' onclick='closeMatch();' /></td>
    <td><input type='submit' value='Match' /> <input type='hidden' value='<?php echo $_GET['page']; ?>' name='page' /></td>
</tr>
</table>
</form>
</div>

<!-- ///////////////////////////////////////// Search Div ////////////////////////////////////// -->
<div id='searchdiv'>
<h3>Search ad_master_data</h3>
<p class='small'>Single quote and back slashes must be escaped.</p>
    <table>
        <tr>
            <td class='right'>Search Criteria: </td>
            <td><input type='text' id='searchval' /></td>
        </tr>
        <tr>
            <td class='right'>Field: </td>
            <td>
                <select id='searchfield'>
                    <option value='accountid'>accountid</option>
                    <option value='ou'>ou</option>
                    <option value='first_name'>first_name</option>
                    <option value='last_name'>last_name</option>
                    <option value='attrib1'>attrib1</option>
                    <option value='attrib2'>attrib2</option>
                    <option value='attrib3'>attrib3</option>
                    <option value='attrib4'>attrib4</option>
                    <option value='temp1'>temp1</option>
                    <option value='temp2'>temp2</option>
                    <option value='temp3'>temp3</option>
                    <option value='temp4'>temp4</option>
                    <option value='temp5'>temp5</option>
                    <option value='temp6'>temp6</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td class='right'><input type='button' value='Cancel' onclick='cancelSearch();' /></td>
            <td><input type='button' value='Search' onclick='search();' /></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
    </table>
    
    <table id='searchtable'>
        <tr>
            <th>Last Name</th>
            <th>First Name</th>
            <th>Username</th>
            <th>OU</th>
        </tr>
    </table>  
</div>

<!-- A few returns -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

</div></body></html>