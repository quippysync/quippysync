<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");
include("../common/inc-repchars.php");

$lastname = escSQ_Slash($_POST['lastname']);

$buffer = "";

$sel = mysqli_query($con,"SELECT last_name,first_name,accountid FROM ad_master_data WHERE match_account = 0 AND match_disabled_account = 0 AND last_name LIKE '%$lastname%'");
while($rec = mysqli_fetch_array($sel))
{
	$buffer .= $rec['last_name'] . "<0|" . $rec['first_name'] . "<0|" . $rec['accountid'] . "<1|";	
}

echo $buffer;

mysqli_close($con);

?>