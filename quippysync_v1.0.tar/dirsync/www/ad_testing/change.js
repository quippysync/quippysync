//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function change()
{
    changeToCache = document.getElementById('changeto').value;
    var params = "changeto=" + encodeURIComponent(changeToCache) + "&id=" + idCache + "&changefrom=" + encodeURIComponent(changeFromCache);    
        
    if(validateChange())
    {
        //alert(changeToCache + " - " + changeFromCache + " - " + idCache);
        sendParams(params,"change.php",changeResponse);
    }
}

function changeResponse()
{
    var response = xmlHttp.responseText;
    if(response == 1 || response == "1")
    {
    }
    else
    {
        alert(changeToCache + " already exists in your Google directory. Location: " + response);
    }
    
    elCache.parentNode.parentNode.getElementsByTagName('td')[5].innerHTML = changeToCache;
    document.getElementById('changediv').style.visibility = "hidden";
    UIP = 0;
}

function validateChange()
{
    if(!adUserObj.exec(changeToCache) && changeToCache !== "")
    {
      alert(adUserMsg);
      return false;
    }
    else
    {
        return true;
    }
}