<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

error_reporting(E_ALL & ~E_NOTICE);

include("../common/inc-seccode.php");
include("../common/inc-repchars.php");

$changeto = $_POST['changeto'];
$changefrom = $_POST['changefrom'];
$id = $_POST['id'];

mysqli_query($con,"UPDATE ad_data SET exempt = 0, change_to = '$changeto' WHERE id = '$id'");
mysqli_query($con,"UPDATE ad_master_data SET match_account = 1 WHERE accountid = '" . escSQ_Slash($changeto) . "'");

$escapeFields[0] = "change_to";
$escapeTable = "ad_data";

for($i=0;$i<=count($escapeFields);$i++)
{
	mysqli_query($con,"UPDATE $escapeTable SET $escapeFields[$i] = REPLACE($escapeFields[$i],'^3]','\\\'), $escapeFields[$i] = REPLACE($escapeFields[$i],'^4]',\"'\") WHERE id = $id");
}

// If there was a previous value that is getting removed, set g_master_data.match_account back to 0
// The records goes back into the pool of potential matches with g_testing
// initchange.js will set the value of changefrom to null if it was previously in exempt
if($changefrom !== null)
{
	mysqli_query($con,"UPDATE ad_master_data SET match_account = 0 WHERE accountid = '" . escSQ_Slash($changefrom) . "'");	
}

// Warn if the user is somewere else in the directory
$sel = mysqli_query($con,"SELECT * FROM ad_all_users WHERE accountid = '" . escSQ_Slash($changeto) . "'");
if(mysqli_num_rows($sel) == 0)
{
	echo 1;
}
else
{
	$rec = mysqli_fetch_array($sel);
	echo $rec['dn'];
}

mysqli_close($con);

?>