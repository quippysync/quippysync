<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");

$searchval = $_POST['searchval']; //There is a note on g_testing/index.php saying to escape single quotes and back slashes. If that note is removed, this field should be run through escSQ_Slash(),
$searchfield = $_POST['searchfield'];

$buffer = "";
$sel = mysqli_query($con,"SELECT accountid,first_name,last_name,ou FROM ad_master_data WHERE " . $searchfield . " LIKE '%" . $searchval . "%'");
while($rec = mysqli_fetch_array($sel))
{
	echo $rec['accountid'] . "<0|" . $rec['first_name'] . "<0|" . $rec['last_name'] . "<0|" . $rec['ou'] . "<1|";
}

mysqli_close($con);

echo $buffer;

?>