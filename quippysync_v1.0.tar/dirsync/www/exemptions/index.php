<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");

?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<title>Common Options</title>
<link rel='stylesheet' type='text/css' href='css.css'></link>
<script src='js.js' type='text/javascript'></script>
<script src='initupd.js' type='text/javascript'></script>
<script src='upd.js' type='text/javascript'></script>
<script src='add.js' type='text/javascript'></script>
<script src='del.js' type='text/javascript'></script>
<script src='showdescription.js' type='text/javascript'></script>
<script src='../common/ajax.js' type='text/javascript'></script>
<script src='../common/rep_rest_chars.js' type='text/javascript'></script>
<script src='../common/valobjects.js' type='text/javascript'></script>

</head><body><div id='maindiv'>

<p>&nbsp;</p>


<?php include("../common/inc-nav.php"); ?>

<table>
    <tr>
        <td class='right'>Exemption: </td>
        <td><input type='text' id='exemption' class='long' /></td>
    </tr>
    <tr>
        <td class='right'>Description: </td>
        <td><textarea id='description'></textarea></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td><input type='button' value='Add' onclick='add();'/></td>
    </tr>
</table>

<table id='maintable'>
<tr>
    <th>Exemption</th>
    <th>Update</th>
    <th>Delete</th>
</tr>

<p>&nbsp;</p>

<?php

$sel = mysqli_query($con,"SELECT * FROM exemptions WHERE type = $table ORDER BY exemption");
while($rec = mysqli_fetch_array($sel))
{
    echo "<tr>";
    echo "<td class='border'><a href='javascript:void(0);' onclick='showDescription(" . $rec['id'] . ");'>" . $rec['exemption'] . "</a></td>";
    echo "<td class='border'><input type='button' value='Update' onclick='initUpd(" . $rec['id'] . ",this);' /></td>";
    echo "<td class='border'><input type='button' value='Delete' onclick='del(" . $rec['id'] . ",this);' /></td>";
    echo "</tr>";
}

mysqli_close($con);

?>
 
</table>
<div id='popupdiv'>
<p>&nbsp;</p>
<h3>Update Exemption</h3>
    <table>
        <tr>
            <td class='right'>Exemption: </td>
            <td><input type='text' id='exemptionu' class='long' /></td>
        </tr>
        <tr>
            <td class='right'>Description: </td>
            <td><textarea id='descriptionu'></textarea></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>        
        <tr>
            <td class='right'><input type='button' value='Update' onclick='upd();'/></td>
            <td><input type='button' value='Cancel' onclick='cancelUpd();' /></td>
        </tr>

    </table>
    
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    
</div></body></html>