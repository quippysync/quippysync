//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function initUpd(recid,el)
{
    if(UIP == 0)
    {
        UIP = 1;
        elCache = el;
        idCache = recid;
        var params = "id=" + recid;
        sendParams(params,"initupd.php",initUpdResponse);
    }
    else
    {
        alert("Finish updating the item");
    }
}

function initUpdResponse()
{
    var response = xmlHttp.responseText;

    var resArr = new Array();
    resArr = response.split("<0|");
    
    var exemption = (resArr[0]);
    var description = (resArr[1]);
    
    document.getElementById('exemptionu').value = exemption;
    document.getElementById('descriptionu').value = description;
    
    document.getElementById('popupdiv').style.top = ctrPopH(250);
    document.getElementById('popupdiv').style.left = ctrPopW(600);
    document.getElementById('popupdiv').style.visibility = "visible";
}

function cancelUpd()
{
    document.getElementById('popupdiv').style.visibility = "hidden";
    UIP = 0;
}