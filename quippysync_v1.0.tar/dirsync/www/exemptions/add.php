<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

error_reporting(E_ALL & ~E_NOTICE);

include("../common/inc-seccode.php");
include("../common/inc-repchars.php");

$exemption = repChar($_POST['exemption']);
$description = repChar($_POST['description']);
$type = $_POST['type'];

mysqli_query($con,"INSERT INTO exemptions (exemption, type, description) VALUES ('$exemption', $type, '$description')");
$id = mysqli_insert_id($con);

$escapeFields[0] = "exemption";
$escapeFields[1] = "description";
$escapeTable = "exemptions";

for($i=0;$i<=count($escapeFields);$i++)
{
	mysqli_query($con,"UPDATE $escapeTable SET $escapeFields[$i] = REPLACE($escapeFields[$i],'^3]','\\\'), $escapeFields[$i] = REPLACE($escapeFields[$i],'^4]',\"'\") WHERE id = $id");
}


// Check for duplicates
$dupSel = mysqli_query($con,"SELECT exemption FROM exemptions WHERE type = $type GROUP BY exemption HAVING COUNT(exemption) > 1");
if(mysqli_num_rows($dupSel) > 0)
{
	echo 0;
}
else
{
	echo $id;	
}

mysqli_close($con);

?>