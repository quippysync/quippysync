//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function upd()
{
    
    exemptionCache = document.getElementById('exemptionu').value;
    descriptionCache = document.getElementById('descriptionu').value;
    
    if(validateUpd())
    {
        var params = "id=" + idCache + "&exemption=" + encodeURIComponent(exemptionCache) + "&description=" + encodeURIComponent(descriptionCache) + "&type=" + table;
        sendParams(params,"upd.php",updResponse);
    }
}

function updResponse()
{
    var response = xmlHttp.responseText;
    if (eval(response) == 0)
    {
        alert("There may be a duplicate option. Please correct before syncing.");
        location.reload();
    }
    else
    {
        elCache.parentNode.parentNode.getElementsByTagName('td')[0].getElementsByTagName('a')[0].innerHTML = (exemptionCache);
        cancelUpd();
    }
}

function validateUpd()
{
    if(eval(table) == 0)
    {
        exemptionObj = adDNObj;
        exemptionMsg = adDNMsg;
    }
    else if(eval(table) == 1)
    {
        exemptionObj = adUserObj;
        exemptionMsg = adUserMsg;
    }
    else if(eval(table) == 2)
    {
        exemptionObj = gDNObj;
        exemptionMsg = gDNMsg;
    }
    else if(eval(table) == 3)
    {
        exemptionObj = gUserObj;
        exemptionMsg = gUserMsg;
    }
    else
    {
        alert("Incorrect page number.");    
    }
    
    if(!exemptionObj.exec(exemptionCache))
    {
      alert(exemptionMsg);
      return false;
    }
    else if(!descriptionObj.exec(descriptionCache))
    {
      alert(descriptionMsg);
      return false;
    }
    else
    {
        return true;
    }
}