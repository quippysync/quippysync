//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function add()
{
    if(UIP == 0)
    {
        
        exemptionCache = document.getElementById('exemption').value;
        descriptionCache = document.getElementById('description').value;
        
        if(validateAdd())
        {
            UIP = 1;
            var params = "exemption=" + encodeURIComponent(exemptionCache) + "&type=" + table + "&description=" + encodeURIComponent(descriptionCache);
            sendParams(params,"add.php",addResponse);
        }
    }
    else
    {
        alert("Please finish updating the current item.");
    }
}

function addResponse()
{
    var response = xmlHttp.responseText;
    
    if (eval(response) == 0)
    {
        alert("There may be a duplicate option. Please correct before syncing.");
        location.reload();
    }
    else
    {
        var newRow = document.getElementById('maintable').insertRow(-1);
       
        //Create cells in new row
        var cell1 = newRow.insertCell(0);
        var cell2 = newRow.insertCell(1);
        var cell3 = newRow.insertCell(2);
        
        //Put content in cells
        cell1.innerHTML = "<a href='javascript:void(0);' onclick='showDescription(" + response + ");'>" + exemptionCache + "</a>";
        cell2.innerHTML = "<input type='button' value='Update' onclick='initUpd(" + response + ",this);' />";
        cell3.innerHTML = "<input type='button' value='Delete' onclick='del(" + response + ",this);' />";
    
        cell1.setAttribute("class","border");
        cell2.setAttribute("class","border");
        cell3.setAttribute("class","border");
        
        document.getElementById('exemption').value = "";
        document.getElementById('description').value = "";
    }
    
    UIP = 0;
}

function validateAdd()
{   
    if(eval(table) == 0)
    {
        exemptionObj = adDNObj;
        exemptionMsg = adDNMsg;
    }
    else if(eval(table) == 1)
    {
        exemptionObj = adUserObj;
        exemptionMsg = adUserMsg;
    }
    else if(eval(table) == 2)
    {
        exemptionObj = gDNObj;
        exemptionMsg = gDNMsg;
    }
    else if(eval(table) == 3)
    {
        exemptionObj = gUserObj;
        exemptionMsg = gUserMsg;
    }
    else
    {
        alert("Incorrect page number.");    
    }
    
    if(!exemptionObj.exec(exemptionCache))
    {
      alert(exemptionMsg);
      return false;
    }
    else if(!descriptionObj.exec(descriptionCache))
    {
      alert(descriptionMsg);
      return false;
    }
    else
    {
        return true;
    }
}