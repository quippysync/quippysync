//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function initMassReset()
{
    
    if (UIP == 0)
    {    
        if(confirm("If you would like to reset all records you have marked for removal, click OK. Otherwise, click Cancel."))
        {
            UIP = 1;
            massReset();
        }
    }
    else
    {
        alert("Please finish updating the current item.");
    }
}

function massReset()
{
    var query_table = document.getElementById('query_table').innerHTML;
    var params = "query_table=" + query_table;
    sendParams(params,"massreset.php",massResetResponse);
}

function massResetResponse()
{
    var response = xmlHttp.responseText;
    if(eval(response) == 1)
    {
        location.reload();
    }
    else
    {
        alert("There was a problem!");
    }
    
    UIP = 0;
}