//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function initMassRemove()
{
    if(UIP == 0)
    {
        UIP = 1;
        document.getElementById('removediv').style.left = ctrPopW(600);
        document.getElementById('removediv').style.top = ctrPopH(250);
        document.getElementById('removediv').style.visibility = "visible";
    }
    else
    {
        alert("Finish updating the item");
    }
}

function clear_login_to_creation_time()
{
    document.getElementById('login_to_creation_time').checked = false;
}

function clear_unused_account_date()
{
    if(document.getElementById('login_to_creation_time').checked)
    {
        document.getElementById('unused_account_date').value = "";
    }
}

function massRemove()
{
    var login_to_creation_time = (document.getElementById('login_to_creation_time').checked) ? "1": "0";
    var unused_account_date = document.getElementById('unused_account_date').value;
    var last_login_threshhold = document.getElementById('last_login_threshhold').value;
    var query_table = document.getElementById('query_table').innerHTML;
    
    if(valMassRemove())
    {
        var params = "login_to_creation_time=" + login_to_creation_time + "&unused_account_date=" + unused_account_date + "&last_login_threshhold=" + last_login_threshhold;
        params += "&query_table=" + query_table;
        sendParams(params,"massremove.php",massRemoveResponse);
    }
}

function massRemoveResponse()
{
    var response = xmlHttp.responseText;
    if(eval(response) == 1)
    {
        location.reload();
    }
    else
    {
        alert("There was a problem!");
        location.reload();
    }
    
    UIP = 0;
}

function cancel()
{
    document.getElementById('removediv').style.visibility = "hidden";
    UIP = 0;
}

function valMassRemove()
{
    var login_to_creation_time = (document.getElementById('login_to_creation_time').checked) ? "1": "0";
    var unused_account_date = document.getElementById('unused_account_date').value;
    var last_login_threshhold = document.getElementById('last_login_threshhold').value;
    
    if(eval(login_to_creation_time) == 1 && unused_account_date.length > 0)
    {
        alert("You can't set unused accounts to their creation date and back to a specific date. It must be one or the other.");
        return false;
    }
    else if(eval(login_to_creation_time) == 0 && unused_account_date.length == 0)
    {
        alert("You must specify what to do with unused account.");
        return false;
    }
    else if(!dateObj.exec(last_login_threshhold))
    {
      alert(dateMsg);
      return false;
    }
    else if(unused_account_date.length !== 0 && !dateObj.exec(unused_account_date))
    {
        alert(dateMsg);
        return false;
    }
    else
    {
        return true;
    }
}