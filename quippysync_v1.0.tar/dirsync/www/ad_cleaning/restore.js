//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function restore(recid,el)
{
    if (UIP == 0)
    {
        UIP = 1;
        idCache = recid;
        elCache  = el.parentNode;
        var query_table = document.getElementById('query_table').innerHTML;
        var params = "id=" + idCache + "&query_table=" + query_table;
        sendParams(params,"restore.php",restoreResponse);
    }
    else
    {
        alert("Please finish updating the current item.");
    }
}

function restoreResponse()
{
    var response = xmlHttp.responseText;
    elCache.innerHTML = "<td class='border'><input type='button' value='Remove' onclick='remove1(" + idCache + ",this)' /></td>";
    UIP = 0;
}