<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");

$login_to_creation_time = $_POST['login_to_creation_time'];
$unused_account_date = $_POST['unused_account_date'];
$last_login_threshhold = $_POST['last_login_threshhold'];
$query_table = $_POST['query_table'];

if(is_numeric($login_to_creation_time) && $login_to_creation_time > 0)
{
	mysqli_query($con,"UPDATE $query_table SET last_logon = creation_time WHERE last_logon = 0");
}

if(is_numeric($unused_account_date) && $unused_account_date > 0)
{
	mysqli_query($con,"UPDATE $query_table SET last_logon = $unused_account_date WHERE last_logon = 0");
}

mysqli_query($con,"UPDATE $query_table SET remove1 = 1 WHERE last_logon < $last_login_threshhold");

mysqli_close($con);

echo 1;

?>