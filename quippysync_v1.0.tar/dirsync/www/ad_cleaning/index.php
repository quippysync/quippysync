<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");
error_reporting(E_ALL & ~E_NOTICE);

?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<title>Clean Google Directory</title>
<link rel='stylesheet' type='text/css' href='css.css'></link>
<script src='js.js' type='text/javascript'></script>
<script src='massreset.js' type='text/javascript'></script>
<script src='massremove.js' type='text/javascript'></script>
<script src='remove.js' type='text/javascript'></script>
<script src='restore.js' type='text/javascript'></script>
<script src='nextpage.js' type='text/javascript'></script>
<script src='../common/ajax.js' type='text/javascript'></script>
<script src='../common/rep_rest_chars.js' type='text/javascript'></script>
<script src='../common/valobjects.js' type='text/javascript'></script>

</head><body><div id='maindiv'>

<?php include("../common/inc-nav.php"); ?>

<p style='color:red;font-weight:900;'>Remember to run a sync immediately before using this cleaning utility.</p>

<table><tr>
<td><a href='javascript:void(0);' onclick='initMassReset();'> Bulk Reset </a></td>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td><a href='javascript:void(0);' onclick='initMassRemove();'> Bulk Remove </a></td>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>

<?php
if($_GET['table'] == 0)
{
    $query_table = "ad_disabled";
    $user_location = "Disabled";
    echo "<td><a href='index.php?table=1&page=" . $page . "'> Clean Exempt Users </a></td>";
}
else
{
    $query_table = "ad_ou_exemptions";
    $user_location = "Exempt";
    echo "<td><a href='index.php?table=0&page=" . $page . "'> Clean Disabled Users </a></td>";
}

echo "<td id='query_table' style='visibility:hidden;display:none;'>" . $query_table . "</td>";

?>
        
</tr></table>

<hr></hr>
<h3><?php echo $user_location ; ?> Users</h3>
<table id='userstable'>

<tr>
    <th>Remove</th>
    <th>Username</th>
    <th>Last Name</th>
    <th>First Name</th>
    <th>Created</th>
    <th>Last Login</th>
</tr>
    
<?php

// Set the current page
if($_POST['current_page'] == null)
{
    $_POST['current_page'] = 0;
}
$current_page = $_POST['current_page'];    

// Set the max records per gage
if($_POST['max_records_per_page'] == null)
{
    $_POST['max_records_per_page'] = 100;
}
$max_records_per_page = $_POST['max_records_per_page'];

$total_rec = mysqli_num_rows(mysqli_query($con,"SELECT id FROM $query_table"));
$num_pages = ceil($total_rec / $max_records_per_page);

$sel = mysqli_query($con,"SELECT * FROM $query_table ORDER BY accountid LIMIT " . ($current_page * $max_records_per_page) . "," . $max_records_per_page . "");
while($rec = mysqli_fetch_array($sel))
{
    echo "<tr>";
    
    if($rec['remove1'] == 0)
    {echo "<td class='border'><input type='button' value='Remove' onclick='remove1(" . $rec['id'] . ",this);' /></td>";}
    else
    {echo "<td class='border'><input type='button' class='red' value='Restore' onclick='restore(" . $rec['id'] . ",this);' /></td>";}
    
    echo "<td class='border'>" . $rec['accountid'] . "</td>";
    echo "<td class='border'>" . $rec['last_name'] . "</td>";
    echo "<td class='border'>" . $rec['first_name'] . "</td>";
    echo "<td class='border'>" . $rec['creation_time'] . "</td>";
    echo "<td class='border'>" . $rec['last_logon'] . "</td>";  
    echo "</tr>";
}

?>

</table>

<!-- Make the page links -->
<p id='navdiv'> | 
<?php
for($i=0;$i<=($num_pages-1);$i++)
{
    if($current_page == $i)
    {
        echo ($i+1) . " | ";
    }
    else
    {
        echo "<a href='javascript:void(0);' onclick='nextPage(" . $i . ");' >" . ($i+1) . "</a> | ";
    }
}
?>
</p>

<!-- Set the records per page -->
<p>
<form action='index.php?table=<?php echo $table; ?>&page=<?php echo $page; ?>' method='post'>Records per page 
    <input type='text' value='<?php echo $max_records_per_page; ?>' name='max_records_per_page' id='max_records_per_page' style='width:3em;' /> 
    <input type='submit' value='Set' />
</form>
</p>

<!-- Next page form-->
<div>
<form action='index.php?table=<?php echo $table; ?>&page=<?php echo $page; ?>' id='nextpageform' method='post'>
    <input type='hidden' value='0' id='current_page' name='current_page' />
    <input type='hidden' value='<?php echo $max_records_per_page; ?>' name='max_records_per_page' /> 
</form>
</div>

<!--Response Div-->
<div id='response'></div>

<!-- ///////////////////////////////////////// Remove Div ////////////////////////////////////// -->
<div id='removediv'>
<h3>Bulk Remove</h3>
    <table>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td class='right'>Remove records if last login is before (yyyymmdd): </td>
            <td><input type='text' id='last_login_threshhold' /></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td class='right'>Set unused account last login to (yyyymmdd): </td>
            <td><input type='text' name='unused_account_date' id='unused_account_date' onkeyup='clear_login_to_creation_time();' /></td>
        </tr>
        <tr>
            <td style='text-align: center;font-weight: 900;'>OR</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td class='right'>Set unused account last login to creation date: </td>
            <td><input type='checkbox' name='login_to_creation_time' id='login_to_creation_time' onclick='clear_unused_account_date();' /></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td style='text-align: right;'><input type='button' value='Cancel' onclick='cancel();' /></td>
            <td><input type='button' value='Remove' onclick='massRemove();' /></td>
        </tr>
    </table>  
    
</div>

<!-- A few returns -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

</div></body></html>