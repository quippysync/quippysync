//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function del(recid,el)
{
    if (UIP == 0)
    {
        elCache = el;
        if (confirm("Are you sure you want to delete this record?") == true)
        {
            UIP = 1;
            var params = "id=" + recid;
            sendParams(params,"del.php",delResponse);
        }
        else
        {
            alert("Delete canceled!");
        }
    }
    else
    {
        alert("Finish updating the item");
    }
}

function delResponse()
{
    response = xmlHttp.responseText;
    document.getElementById('maintable').deleteRow(elCache.parentNode.parentNode.rowIndex);

    UIP = 0
}