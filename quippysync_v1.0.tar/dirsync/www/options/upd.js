//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function upd()
{
    
    optionCache = document.getElementById('optionupd').value;
    valueCache = document.getElementById('valueupd').value;
    descriptionCache = document.getElementById('descriptionupd').value;
    
    if(validateUpd())
    {
        var params = "id=" + idCache + "&option=" + optionCache + "&value1=" + encodeURIComponent(valueCache) + "&description=" + encodeURIComponent(descriptionCache) + "&type=" + table;
        sendParams(params,"upd.php",updResponse);
    }
}

function updResponse()
{
    var response = xmlHttp.responseText;
    if (eval(response) == 0)
    {
        alert("There may be a duplicate option. Please correct before syncing.");
        location.reload();
    }
    else
    {
        elCache.parentNode.parentNode.getElementsByTagName('td')[0].getElementsByTagName('a')[0].innerHTML = optionCache;
        elCache.parentNode.parentNode.getElementsByTagName('td')[1].innerHTML = valueCache;
        cancelUpd();
    }
}

function validateUpd()
{
    if(!valueObj.exec(valueCache))
    {
      alert(valueMsg);
      return false;
    }
    else if(!optionObj.exec(optionCache))
    {
      alert(optionMsg);
      return false;
    }
    else if(!descriptionObj.exec(descriptionCache))
    {
      alert(descriptionMsg);
      return false;
    }
    else
    {
        return true;
    }
}