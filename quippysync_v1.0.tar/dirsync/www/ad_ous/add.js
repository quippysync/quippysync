//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function add()
{
    if(UIP == 0)
    {
        ouCache = document.getElementById('ou').value;
        dnCache = document.getElementById('dn').value;
        scriptCache = document.getElementById('script').value;
        group1Cache = document.getElementById('group1').value;
        storage_pathCache = document.getElementById('storage_path').value;
        drive_letterCache = document.getElementById('drive_letter').value;
        server_nameCache = document.getElementById('server_name').value;
        user_shareCache = document.getElementById('user_share').value;
        attrib1Cache = document.getElementById('attrib1').value;
        attrib2Cache = document.getElementById('attrib2').value;
        attrib3Cache = document.getElementById('attrib3').value;
        attrib4Cache = document.getElementById('attrib4').value;
        includeCache = document.getElementById('include').value;
                
        if(validateAdd())
        {
            UIP = 1;
            alert(dnCache);
            var params = "ou=" + encodeURIComponent(ouCache) + "&dn=" + encodeURIComponent(dnCache) + "&script=" + encodeURIComponent(scriptCache) + "&group1=" + encodeURIComponent(group1Cache);
            params += "&storage_path=" + encodeURIComponent(storage_pathCache) + "&drive_letter=" + drive_letterCache + "&server_name=" + encodeURIComponent(server_nameCache) + "&user_share=" + encodeURIComponent(user_shareCache);
            params += "&attrib1=" + encodeURIComponent(attrib1Cache) + "&attrib2=" + encodeURIComponent(attrib2Cache) + "&attrib3=" + encodeURIComponent(attrib3Cache) + "&attrib4=" + encodeURIComponent(attrib4Cache);
            params += "&include=" + includeCache;
            sendParams(params,"add.php",addResponse);
        }
    }
    else
    {
        alert("Please finish updating the current item.");
    }
}


function addResponse()
{
    var response = xmlHttp.responseText;
    if(eval(response) == 0)
    {
        alert("There is a duplicate OU or DN. This must be fixed before syncing.");
        location.reload();
    }
    else
    {
        document.getElementById('newoudiv').innerHTML += "<hr></hr><table id='" + ouCache + "table'></table>";
        var row = "";
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "OU: ";
        row.insertCell(1).innerHTML = (ouCache);
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
    
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "DN: ";
        row.insertCell(1).innerHTML = (dnCache);
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
    
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Script: ";
        row.insertCell(1).innerHTML = scriptCache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
    
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Group: ";
        row.insertCell(1).innerHTML = group1Cache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
    
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Storage Path: ";
        row.insertCell(1).innerHTML = storage_pathCache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Drive Letter: ";
        row.insertCell(1).innerHTML = drive_letterCache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Server Name: ";
        row.insertCell(1).innerHTML = server_nameCache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Users Share: ";
        row.insertCell(1).innerHTML = user_shareCache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Attribute 1: ";
        row.insertCell(1).innerHTML = attrib1Cache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Attribute 2: ";
        row.insertCell(1).innerHTML = attrib2Cache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Attribute 3: ";
        row.insertCell(1).innerHTML = attrib3Cache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Attribute 4: ";
        row.insertCell(1).innerHTML = attrib4Cache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
    
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "Include: ";
        row.insertCell(1).innerHTML = includeCache;
        row.getElementsByTagName('td')[0].setAttribute("class","border");
        row.getElementsByTagName('td')[1].setAttribute("class","border");
        
        row = document.getElementById(ouCache + 'table').insertRow(-1);
        row.insertCell(0).innerHTML = "&nbsp;";
        row.insertCell(1).innerHTML = "<input type='button' value='Update' onclick='initUpd(" + response + ",this);' /> <input type='button' value='Delete' onclick='del(" + response + ",this);' />";
    }

    UIP = 0;
}

function validateAdd()
{
    if(!ouObj.exec(ouCache))
    {
      alert(ouMsg);
      return false;
    }
    else if(!adDNObj.exec(dnCache))
    {
      alert(adDNMsg);
      return false;
    }
    else if(!adGrpObj.exec(group1Cache))
    {
      alert(adGrpMsg);
      return false;
    }
    else if(!scriptObj.exec(scriptCache))
    {
      alert(scriptMsg);
      return false;
    }    
    else if(!storage_pathObj.exec(storage_pathCache))
    {
      alert(storage_pathMsg);
      return false;
    }
    else if(!drive_letterObj.exec(drive_letterCache))
    {
      alert(drive_letterMsg);
      return false;
    }
    else if(!server_nameObj.exec(server_nameCache))
    {
      alert(server_nameMsg);
      return false;
    }
    else if(!user_shareObj.exec(user_shareCache))
    {
      alert(user_shareMsg);
      return false;
    }  
    else if(!attribObj.exec(attrib1Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(!attribObj.exec(attrib2Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(!attribObj.exec(attrib3Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(!attribObj.exec(attrib4Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(eval(includeCache) > 2)
    {
      alert("Include must be a 0 or 1.");
      return false;
    }
    else
    {
        return true;
    }
}