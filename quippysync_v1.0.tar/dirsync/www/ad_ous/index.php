<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");

?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<title>AD OUs</title>
<link rel='stylesheet' type='text/css' href='css.css'></link>
<script src='js.js' type='text/javascript'></script>
<script src='initupd.js' type='text/javascript'></script>
<script src='upd.js' type='text/javascript'></script>
<script src='add.js' type='text/javascript'></script>
<script src='del.js' type='text/javascript'></script>
<script src='../common/ajax.js' type='text/javascript'></script>
<script src='../common/rep_rest_chars.js' type='text/javascript'></script>
<script src='../common/valobjects.js' type='text/javascript'></script>

</head><body><div id='maindiv'>
<p>&nbsp;</p>

<?php include("../common/inc-nav.php"); ?>

<p>&nbsp;</p>

<table>
    <tr>
        <td class='right'>OU: </td>
        <td><input class='long' type='text' id='ou' /></td>
    </tr>
    <tr>
        <td class='right'>DN: </td>
        <td><input class='long' type='text' id='dn' /></td>
    </tr>
    <tr>
        <td class='right'>Group: </td>
        <td><input class='long' type='text' id='group1' /></td>
    </tr>
    <tr>
        <td class='right'>Script: </td>
        <td><input class='long' type='text' id='script' /></td>
    </tr>
    <tr>
        <td class='right'>Storage Path: </td>
        <td><input class='long' type='text' id='storage_path' /></td>
    </tr>
    <tr>
        <td class='right'>Drive Letter: </td>
        <td><input class='long' type='text' id='drive_letter' /></td>
    </tr>
    <tr>
        <td class='right'>Server Name: </td>
        <td><input class='long' type='text' id='server_name' /></td>
    </tr>
    <tr>
        <td class='right'>Users Share: </td>
        <td><input class='long' type='text' id='user_share' /></td>
    </tr>
    <tr>
        <td class='right'>Attribute 1: </td>
        <td><input class='long' type='text' id='attrib1' /></td>
    </tr>
    <tr>
        <td class='right'>Attribute 2: </td>
        <td><input class='long' type='text' id='attrib2' /></td>
    </tr>
    <tr>
        <td class='right'>Attribute 3: </td>
        <td><input class='long' type='text' id='attrib3' /></td>
    </tr>
    <tr>
        <td class='right'>Attribute 4: </td>
        <td><input class='long' type='text' id='attrib4' /></td>
    </tr>
    <tr>
        <td class='right'>Include (0 or 1): </td>
        <td><input class='long' type='text' id='include' value='1' /></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td><input type='button' value='Add' onclick='add();'/></td>
    </tr>
</table>

<p>&nbsp;</p>

<?php

$sel = mysqli_query($con,"SELECT * FROM ad_ous ORDER BY ou");
while($rec = mysqli_fetch_array($sel))
{
    echo "<hr></hr>";
    echo "<table>";
    
    echo "<tr><td class='border'>OU: </td>";
    echo "<td class='border'>" . ($rec['ou']) . "</td></tr>";

    echo "<tr><td class='border'>DN: </td>";
    echo "<td class='border'>" . ($rec['dn']) . "</td></tr>";

    echo "<tr><td class='border'>Script: </td>";
    echo "<td class='border'>" . ($rec['script']) . "</td></tr>";

    echo "<tr><td class='border'>Group: </td>";
    echo "<td class='border'>" . ($rec['group1']) . "</td></tr>";

    echo "<tr><td class='border'>Storage Path: </td>";
    echo "<td class='border'>" . ($rec['storage_path']) . "</td></tr>";

    echo "<tr><td class='border'>Drive Letter: </td>";
    echo "<td class='border'>" . ($rec['drive_letter']) . "</td></tr>";

    echo "<tr><td class='border'>Server Name: </td>";
    echo "<td class='border'>" . ($rec['server_name']) . "</td></tr>";

    echo "<tr><td class='border'>Users Share: </td>";
    echo "<td class='border'>" . ($rec['user_share']) . "</td></tr>";

    echo "<tr><td class='border'>Attribute 1: </td>";
    echo "<td class='border'>" . ($rec['attrib1']) . "</td></tr>";

    echo "<tr><td class='border'>Attribute 2: </td>";
    echo "<td class='border'>" . ($rec['attrib2']) . "</td></tr>";

    echo "<tr><td class='border'>Attribute 3: </td>";
    echo "<td class='border'>" . ($rec['attrib3']) . "</td></tr>";

    echo "<tr><td class='border'>Attribute 4: </td>";
    echo "<td class='border'>" . ($rec['attrib4']) . "</td></tr>";

    echo "<tr><td class='border'>Include: </td>";
    echo "<td class='border'>" . $rec['include_in_export'] . "</td></tr>";
    
    echo "<tr><td>&nbsp;</td>";
    echo "<td><input type='button' value='Update' onclick='initUpd(" . $rec['id'] . ",this);' /> ";
    echo "<input type='button' value='Delete' onclick='del(" . $rec['id'] . ",this);' /></td></tr>";

    echo "</tr>";
    echo "</table>";
    echo "<p>&nbsp;</p>";
}

mysqli_close($con);

?>
 
<!--/////////////////////////////////////////////////////////////////////////////////////////////////////-->

<div id='newoudiv'></div>

<!--/////////////////////////////////////////////////////////////////////////////////////////////////////-->


<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    
</div></body></html>