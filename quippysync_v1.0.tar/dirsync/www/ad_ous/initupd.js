//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function initUpd(recid,el)
{
    if(UIP == 0)
    {
        UIP = 1;
        elCache = el;
        idCache = recid;
        stopCache = eval(elCache.parentNode.parentNode.parentNode.rows.length - 2);
        buttonsCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[eval(stopCache+1)].getElementsByTagName('td')[1].innerHTML;
        
        for(i=0;i<=stopCache;i++)
        {
            rowsArr[i] = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[i].getElementsByTagName('td')[1].innerHTML;
            elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[i].getElementsByTagName('td')[1].innerHTML = "<input class='long' type='text' value='" + escapeSQ(rowsArr[i]) + "' />";
        }
        
        elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[eval(stopCache+1)].getElementsByTagName('td')[1].innerHTML = "<input type='button' onclick='upd(this)' value='Send' /> <input type='button' onclick='cancelUpd(this)' value='Cancel' />";
        
    }
    else
    {
        alert("Finish updating the item");
    }
}

function cancelUpd(el)
{
    elCache = el;
        for(i=0;i<=stopCache;i++)
        {
            elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[i].getElementsByTagName('td')[1].innerHTML = rowsArr[i];
        }
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[eval(stopCache+1)].getElementsByTagName('td')[1].innerHTML = buttonsCache;
    UIP = 0;
}