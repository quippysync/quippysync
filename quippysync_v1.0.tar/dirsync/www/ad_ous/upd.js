//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function upd(el)
{
    elCache = el;
    
    ouCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[0].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    dnCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[1].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    scriptCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[2].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    group1Cache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[3].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    storage_pathCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[4].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    drive_letterCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[5].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    server_nameCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[6].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    user_shareCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[7].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    attrib1Cache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[8].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    attrib2Cache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[9].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    attrib3Cache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[10].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    attrib4Cache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[11].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    includeCache = elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[12].getElementsByTagName('td')[1].getElementsByTagName('input')[0].value;
    
    if(validateUpd())
    {
        UIP = 1;
            var params = "ou=" + encodeURIComponent(ouCache) + "&dn=" + encodeURIComponent(dnCache) + "&script=" + encodeURIComponent(scriptCache) + "&group1=" + encodeURIComponent(group1Cache);
            params += "&storage_path=" + encodeURIComponent(storage_pathCache) + "&drive_letter=" + drive_letterCache + "&server_name=" + encodeURIComponent(server_nameCache) + "&user_share=" + encodeURIComponent(user_shareCache);
            params += "&attrib1=" + encodeURIComponent(attrib1Cache) + "&attrib2=" + encodeURIComponent(attrib2Cache) + "&attrib3=" + encodeURIComponent(attrib3Cache) + "&attrib4=" + encodeURIComponent(attrib4Cache);
            params += "&include=" + includeCache + "&id=" + idCache;
        sendParams(params,"upd.php",updResponse);
    }
}

function updResponse()
{
    var response = xmlHttp.responseText;
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[0].getElementsByTagName('td')[1].innerHTML = (ouCache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[1].getElementsByTagName('td')[1].innerHTML = (dnCache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[2].getElementsByTagName('td')[1].innerHTML = (scriptCache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[3].getElementsByTagName('td')[1].innerHTML = (group1Cache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[4].getElementsByTagName('td')[1].innerHTML = (storage_pathCache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[5].getElementsByTagName('td')[1].innerHTML = (drive_letterCache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[6].getElementsByTagName('td')[1].innerHTML = (server_nameCache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[7].getElementsByTagName('td')[1].innerHTML = (user_shareCache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[8].getElementsByTagName('td')[1].innerHTML = (attrib1Cache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[9].getElementsByTagName('td')[1].innerHTML = (attrib2Cache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[10].getElementsByTagName('td')[1].innerHTML = (attrib3Cache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[11].getElementsByTagName('td')[1].innerHTML = (attrib4Cache);
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[12].getElementsByTagName('td')[1].innerHTML = includeCache;
    elCache.parentNode.parentNode.parentNode.getElementsByTagName('tr')[13].getElementsByTagName('td')[1].innerHTML = buttonsCache;
    UIP = 0
}

function validateUpd()
{
    if(!ouObj.exec(ouCache))
    {
      alert(ouMsg);
      return false;
    }
    else if(!adDNObj.exec(dnCache))
    {
      alert(adDNMsg);
      return false;
    }
    else if(!adGrpObj.exec(group1Cache))
    {
      alert(adGrpMsg);
      return false;
    }    
    else if(!scriptObj.exec(scriptCache))
    {
      alert(scriptMsg);
      return false;
    }    
    else if(!storage_pathObj.exec(storage_pathCache))
    {
      alert(storage_pathMsg);
      return false;
    }
    else if(!drive_letterObj.exec(drive_letterCache))
    {
      alert(drive_letterMsg);
      return false;
    }
    else if(!server_nameObj.exec(server_nameCache))
    {
      alert(server_nameMsg);
      return false;
    }
    else if(!user_shareObj.exec(user_shareCache))
    {
      alert(user_shareMsg);
      return false;
    }  
    else if(!attribObj.exec(attrib1Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(!attribObj.exec(attrib2Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(!attribObj.exec(attrib3Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(!attribObj.exec(attrib4Cache))
    {
      alert(attribMsg);
      return false;
    }
    else if(eval(includeCache) > 1 || eval(includeCache) < 0)
    {
      alert("Include must be a 0 or 1.");
      return false;
    }
    else
    {
        return true;
    }
}