<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

include("../common/inc-seccode.php");
include("../common/inc-repchars.php");

$id = $_POST['id'];
$ou = repChar($_POST['ou']);
$dn = repChar($_POST['dn']);
$script = repChar($_POST['script']);
$group1 = repChar($_POST['group1']);
$storage_path = repChar($_POST['storage_path']);
$drive_letter = $_POST['drive_letter'];
$server_name = $_POST['server_name'];
$user_share = repChar($_POST['user_share']);
$attrib1 = repChar($_POST['attrib1']);
$attrib2 = repChar($_POST['attrib2']);
$attrib3 = repChar($_POST['attrib3']);
$attrib4 = repChar($_POST['attrib4']);
$include = $_POST['include'];

$query = "UPDATE ad_ous SET ";
$query .= "ou = '" . $ou;
$query .= "', dn = '" . $dn;
$query .= "', script = '" . $script;
$query .= "', group1 = '" . $group1;
$query .= "', storage_path = '" . $storage_path;
$query .= "', drive_letter = '" . $drive_letter;
$query .= "', server_name = '" . $server_name;
$query .= "', user_share = '" . $user_share;
$query .= "', attrib1 = '" . $attrib1;
$query .= "', attrib2 = '" . $attrib2;
$query .= "', attrib3 = '" . $attrib3;
$query .= "', attrib4 = '" . $attrib4;
$query .= "', include_in_export = " . $include;
$query .= " WHERE id = " . $id;

mysqli_query($con,$query);

$escapeFields[0] = "ou";
$escapeFields[1] = "dn";
$escapeFields[2] = "group1";
$escapeFields[3] = "script";
$escapeFields[4] = "storage_path";
$escapeFields[5] = "user_share";
$escapeFields[6] = "attrib1";
$escapeFields[7] = "attrib2";
$escapeFields[8] = "attrib3";
$escapeFields[9] = "attrib4";
$escapeTable = "ad_ous";

for($i=0;$i<=count($escapeFields);$i++)
{
    mysqli_query($con,"UPDATE $escapeTable SET $escapeFields[$i] = REPLACE($escapeFields[$i],'^3]','\\\'), $escapeFields[$i] = REPLACE($escapeFields[$i],'^4]',\"'\") WHERE id = $id");
}

// Check for duplicates
$dupSelOU = mysqli_query($con,"SELECT ou FROM ad_ous GROUP BY ou HAVING COUNT(ou) > 1");
$dupSelDN = mysqli_query($con,"SELECT dn FROM ad_ous GROUP BY dn HAVING COUNT(dn) > 1");
if(mysqli_num_rows($dupSelOU) > 0 || mysqli_num_rows($dupSelDN) > 0)
{
    echo 0;
}
else
{
    echo 1;	
}

mysqli_close($con);

?>