//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

var UIP = 0;
var elCache = "";
var idCache = 0;
var ouCache = "";
var dnCache = "";
var scriptCache = "";
var group1Cache = "";
var storage_pathCache = "";
var drive_letterCache = "";
var server_nameCache = "";
var user_shareCache = "";
var attrib1Cache = "";
var attrib2Cache = "";
var attrib3Cache = "";
var attrib4Cache = "";
var includeCache = 1;
var stopCache = 0;
var buttonsCache = "";
var rowsArr = new Array();

/*

~!@#$%^&*()_+{}|:"<>?`-=[]\;',./ 5aB
~!@#$%^&*()_+{}|:"<>?`-=[]\;',./ 5aB
~!@#$%^&*()_+{}|:"<>?`-=[]\;',./ 5aB

Not allowed in windows file or folder name = \/:*?":<>|
AD will let you use any character in an ou or in a username

Not allowed in a Google Username

These characters are not allowed: [space] ! " # $ % & ( ) * + , / : ; < = > ? @ [ \ ] ^ ` { | } ~           ////// You can have - _ ' .
In a Google OU you can have any character except for a /

*/