var UIP = 0;
var pathCache = "";
var lastDirCache = "";
var dirCache = "";
var docCache = "";

function ctrPopW(divWidth)
{
    var leftPos = eval(window.pageXOffset + 0.5*window.innerWidth - 0.5*divWidth);
    return leftPos + "px";
}

function ctrPopH(divHeight)
{
    var topPos = eval(window.pageYOffset + 0.5*window.innerHeight - 0.5*divHeight);
    return topPos + "px";
}