<?php

include("../common/inc-seccode.php");

$doc = $_POST['doc'];

echo file_get_contents($doc);

mysqli_close($con);

?>