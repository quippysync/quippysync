<?php

include("../common/inc-seccode.php");

$dir = $_POST['dir'];
$dotdot = $_POST['dotdot'];

if($dotdot == 1)
{
    $dirArr = explode("/",$dir);
    array_pop($dirArr);
    $dir = implode("/",$dirArr);
}

$buffer = "";
if(in_array("dirsyncroot",scandir($dir)))
{
    $dir = "/var/local/dirsync/Data";
}

foreach(scandir($dir) as $val)
{
    $buffer .= $val . "<0|";    
}

$buffer .= "<1|" . $dir;

echo $buffer;

mysqli_close($con);

?>