<?php include("../common/inc-seccode.php"); ?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<title>AD OUs</title>
<link rel='stylesheet' type='text/css' href='css.css'></link>
<script src='js.js' type='text/javascript'></script>
<script src='getdir.js' type='text/javascript'></script>
<script src='../common/ajax.js' type='text/javascript'></script>

</head><body><div id='maindiv'>

<?php include("../common/inc-nav.php"); ?>
<p id='dirpath'>&nbsp;</p>

<table><tr><td id='browsetd'>

<?php

$rootdir = "/var/local/dirsync/Data";
foreach(scandir($rootdir) as $val)
{
    if($val !== "." && $val !== "..")
    {echo "<div><a href='javascript:void(0);' onclick='getdir(\"" . $rootdir . "/" . $val . "\",0);'>" . $val . "</a></div>";}    
}

mysqli_close($con);

?>

</td>

</tr></table>


<div id='contentdiv'><h3></h3><textarea id='contentta' wrap='off'></textarea>
<div><a href='javascript:void(0);' onclick='closeDoc();'>Close</a></div>
</div>

<!--/////////////////////////////////////////////////////////////////////////////////////////////////////-->


<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    
</div></body></html>