function getdir(dir,dotdot)
{
    if(UIP == 0)
    {
        UIP = 1;
        var dirObj = new RegExp(/\./g);
        if(dirObj.exec(dir)) //If it has a . in it, it is a document rather than a directory.
        {
            docCache = dir;
            var params = "doc=" + dir;
            sendParams(params,"getdoc.php",getDocResponse);
        }
        else
        {
            dirCache = dir;
            var params = "dir=" + dirCache + "&dotdot=" + dotdot;
            sendParams(params,"getdir.php",getdirResponse);
        }
    }
    else
    {
        alert("Finish updating the item");
    }
}

function getdirResponse()
{
    var response = xmlHttp.responseText;
    
    var resArr = new Array();
    resArr = response.split("<1|");
    
    var dirArr = new Array();
    dirArr = resArr[0].split("<0|");
    
    dirCache = resArr[1];
    
    document.getElementById('dirpath').innerHTML = dirCache;
    
    document.getElementById('browsetd').innerHTML = "<a href='javascript:void(0);' onclick='getdir(\"" + dirCache + "\",1);'>..</a>";
    
    for(i in dirArr)
    {
        if(dirArr[i] !== "." && dirArr[i] !== "..")
        {
            document.getElementById('browsetd').innerHTML += "<div><a href='javascript:void(0);' onclick='getdir(\"" + dirCache + "/" + dirArr[i] + "\",0);'>" + dirArr[i] + "</a></div>";
        }
    }
    
    UIP = 0;
}

function getDocResponse()
{
    var response = xmlHttp.responseText;
    document.getElementById('contentdiv').style.top = ctrPopH(600);
    document.getElementById('contentdiv').style.left = ctrPopW(1000);
    
    document.getElementById('contentdiv').getElementsByTagName('h3')[0].innerHTML = "Contents: " + docCache;
    document.getElementById('contentta').value = response;
    document.getElementById('contentdiv').style.visibility = "visible";
    UIP = 0;
}

function closeDoc()
{
    document.getElementById('contentdiv').style.visibility = "hidden";
}