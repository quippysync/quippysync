//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function initChpwd(recid,el)
{
    if(UIP == 0)
    {
        UIP = 1;
        idCache = recid;
        document.getElementById('popupdiv').style.left = ctrPopW(600);
        document.getElementById('popupdiv').style.top = ctrPopH(300);
        document.getElementById('popupdiv').style.visibility = "visible";
        document.getElementById('firstname_change').innerHTML = el.parentNode.parentNode.getElementsByTagName('td')[0].innerHTML;
    }
    else
    {
        alert("Please finish updating the item.");
    }
}

function cancelChpwd()
{
    document.getElementById('popupdiv').style.visibility = "hidden";
    document.getElementById('passwordu').value = "";
    document.getElementById('verifypasswordu').value = "";
    document.getElementById('userspasswordu').value = "";
    UIP = 0;
}

function chpwd()
{
    var password = document.getElementById('passwordu').value;
    var verifyPassword = document.getElementById('verifypasswordu').value;
    var usersPassword = document.getElementById('userspasswordu').value;
    
    if(validateChpwd())
    {
        var params = "id=" + idCache;
        params += "&userspassword=" + encodeURIComponent(usersPassword) + "&password=" + encodeURIComponent(password);
        sendParams(params,"chpwd.php",chpwdResponse);
    }
}

function chpwdResponse()
{
    var response = xmlHttp.responseText;
    if(eval(response) == 1)
    {
        alert("The password was changed successfully.");
        cancelChpwd();
    }
    else if(eval(response) == 0)
    {
        alert("Logged on user's password was incorrect");
    }
    else
    {
        alert("Unknown error occurred.");
    }
    UIP = 0;
}

function validateChpwd()
{
    var password = document.getElementById('passwordu').value;
    var verifyPassword = document.getElementById('verifypasswordu').value;
    var usersPassword = document.getElementById('userspasswordu').value;

    if(password !== verifyPassword)
    {
        alert("Passwords do not match!");
        return false;
    }
    else if(!passwordObj.exec(password))
    {
      alert(passwordMsg);
      return false;
    }
    else if(!passwordObj.exec(usersPassword))
    {
      alert(passwordMsg);
      return false;
    }
    else
    {
        return true;
    }
}