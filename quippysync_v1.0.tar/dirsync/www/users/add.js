//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function add()
{
    if(UIP == 0)
    {
        
        firstnameCache = document.getElementById('firstname').value;
        lastnameCache = document.getElementById('lastname').value;
        emailCache = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        var verifyPassword = document.getElementById('verifypassword').value;
        var usersPassword = document.getElementById('userspassword').value;
        
        if(validateAdd())
        {
            UIP = 1;
            var params = "firstname=" + encodeURIComponent(firstnameCache) + "&lastname=" + encodeURIComponent(lastnameCache) + "&email=" + emailCache;
            params += "&userspassword=" + encodeURIComponent(usersPassword) + "&password=" + encodeURIComponent(password);
            sendParams(params,"add.php",addResponse);
        }
    }
    else
    {
        alert("Please finish updating the current item.");
    }
}

function addResponse()
{
    var response = xmlHttp.responseText;
    if (eval(response) > 0)
    {
        var newRow = document.getElementById('maintable').insertRow(-1);
       
        //Create cells in new row
        var cell1 = newRow.insertCell(0);
        var cell2 = newRow.insertCell(1);
        var cell3 = newRow.insertCell(2);
        var cell4 = newRow.insertCell(3);
        var cell5 = newRow.insertCell(4);
        
        ////Put content in cells
        cell1.innerHTML = firstnameCache;
        cell2.innerHTML = lastnameCache;
        cell3.innerHTML = emailCache;
        cell4.innerHTML = "<input type='button' value='Chpwd' onclick='initChpwd(" + response + ",this)' />";
        cell5.innerHTML = "<input type='button' value='Delete' onclick='del(" + response + ",this);' />";
    
        cell1.setAttribute("class","border");
        cell2.setAttribute("class","border");
        cell3.setAttribute("class","border");
        cell4.setAttribute("class","border");
        cell5.setAttribute("class","border");
        
        document.getElementById('firstname').value = "";
        document.getElementById('lastname').value = "";
        document.getElementById('email').value = "";
        document.getElementById('password').value = "";
        document.getElementById('verifypassword').value = "";
        document.getElementById('userspassword').value = "";
    }
    else if(eval(response) == -1)
    {
        alert("That user already exists!");
    }
    else if(eval(response) == 0)
    {
        alert("Record was not added. The logged on user's password may be wrong.");   
    }
    else
    {
        alert("A non-specific error occurred.");   
    }

        
    UIP = 0;
}

function validateAdd()
{    
    var password = document.getElementById('password').value;
    var verifyPassword = document.getElementById('verifypassword').value;
    
    if(password !== verifyPassword)
    {
        alert("Passwords do not match.");
        return false;
    }
    else if(!passwordObj.exec(password))
    {
      alert(passwordMsg);
      return false;
    }
    else if(!nameObj.exec(firstnameCache))
    {
      alert(nameMsg);
      return false;
    }
    else if(!nameObj.exec(lastnameCache))
    {
      alert(nameMsg);
      return false;
    }
    else if(!emailObj.exec(emailCache))
    {
      alert(emailMsg);
      return false;
    }
    else
    {
        return true;
    }
}