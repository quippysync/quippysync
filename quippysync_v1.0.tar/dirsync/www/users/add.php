<?php

//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.


include("../common/inc-con.php");

$firstname = base64_encode($_POST['firstname']);
$lastname = base64_encode($_POST['lastname']);
$username = base64_encode(strtolower($_POST['email']));
$userspassword = sha1($_POST['userspassword']); //The password of the logged on user
$password = sha1($_POST['password']);

// Make sure the logged on user supplied the correct password
$pwdCheckSel = mysqli_query($con, "SELECT autonumber FROM users WHERE autonumber = '$duserid' and password = '$userspassword'");
if(mysqli_num_rows($pwdCheckSel) > 0)
{
    
    // Make sure the user doesn't already exist
    $dupSel = mysqli_query($con,"SELECT autonumber FROM users where username = '$username'");
    if(mysqli_num_rows($dupSel) > 0)
    {
        mysqli_close($con);
        echo -1;
        exit();
    }
    else
    {
        mysqli_query($con,"INSERT INTO users (firstname, lastname, username, password) VALUES ('$firstname', '$lastname', '$username', '$password')");
        echo mysqli_insert_id($con);
    }
}
else
{
    echo 0;
}


mysqli_close($con);

?>