<?php
//     Copyright 2015 Anthony Tranquillo

//     This file is part of Quippysync.

//    Quippysync is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.

//    Quippysync is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.


include("../common/inc-con.php");
?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<title>Common Options</title>
<link rel='stylesheet' type='text/css' href='css.css'></link>
<script src='js.js' type='text/javascript'></script>
<script src='initupd.js' type='text/javascript'></script>
<script src='upd.js' type='text/javascript'></script>
<script src='add.js' type='text/javascript'></script>
<script src='del.js' type='text/javascript'></script>
<script src='chpwd.js' type='text/javascript'></script>
<script src='../common/ajax.js' type='text/javascript'></script>
<script src='../common/valobjects.js' type='text/javascript'></script>

</head><body><div id='maindiv'>
<p>&nbsp;</p>

<?php include("../common/inc-nav.php"); ?>

<p>&nbsp;</p>

<table>
    <tr>
        <td class='right'>First Name: </td>
        <td><input type='text' id='firstname' /></td>
    </tr>
    <tr>
        <td class='right'>Last Name: </td>
        <td><input type='text' id='lastname' /></td>
    </tr>
    <tr>
        <td class='right'>Email: </td>
        <td><input type='text' id='email' /></td>
    </tr>
    <tr>
        <td class='right'>Password: </td>
        <td><input type='password' id='password' /></td>
    </tr>
    <tr>
        <td class='right'>Verify Password: </td>
        <td><input type='password' id='verifypassword' /></td>
    </tr>
    <tr>
        <td class='right'>Logged On User's Password: </td>
        <td><input type='password' id='userspassword' /></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td><input type='button' value='Add' onclick='add();'/></td>
    </tr>
</table>

<table id='maintable'>
<tr>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>
    <th>Chpwd</th>
    <th>Delete</th>
</tr>

<p>&nbsp;</p>

<?php

$sel = mysqli_query($con,"SELECT * FROM users");
while($rec = mysqli_fetch_array($sel))
{
    echo "<tr>";
    echo "<td class='border'>" . base64_decode($rec['firstname']) . "</td>";
    echo "<td class='border'>" . base64_decode($rec['lastname']) . "</td>";
    echo "<td class='border'>" . base64_decode($rec['username']) . "</td>";
    echo "<td class='border'><input type='button' value='Chpwd' onclick='initChpwd(" . $rec['autonumber'] . ",this)' /></td>";
    echo "<td class='border'><input type='button' value='Delete' onclick='del(" . $rec['autonumber'] . ",this)' /></td>";
    echo "</tr>";
}

mysqli_close($con);

?>
 
</table>

<div id='popupdiv'>
<p>&nbsp;</p>
<h3>Change password for <span id='firstname_change'></span></h3>
<table>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td class='right'>New Password: </td>
        <td><input type='password' id='passwordu' /></td>
    </tr>
    <tr>
        <td class='right'>Verify Password: </td>
        <td><input type='password' id='verifypasswordu' /></td>
    </tr>
    <tr>
        <td class='right'>Logged On User's Password: </td>
        <td><input type='password' id='userspasswordu' /></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td class='right'><input type='button' value='Reset Password' onclick='chpwd();'/></td>
        <td><input type='button' value='Cancel' onclick='cancelChpwd();'/></td>
    </tr>

</table>
    
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    
</div></body></html>