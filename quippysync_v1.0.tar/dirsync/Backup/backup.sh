#!/bin/bash

#     Copyright 2015 Anthony Tranquillo

#     This file is part of Quippysync.

#    Quippysync is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Quippysync is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

# Set variables
current_date=`date '+%Y%m%d'`
mysqluser="dirsyncsql";
mysqlpass="quippysync";
mysqldb="dirsync";
mysqldb2="ad_template";
mysqldb3="";
mysqldb4="";
mysqldb5="";
mysqldb6="";
sftpuser="quippysyncbackup";
sftpport=8890;
sftpserver="10.1.1.2";
sftpdir="dirsync_backups";
sftpkey="/root/.ssh/mysshkey"
rootdir="/var/local/dirsync";
tarstring="$rootdir --exclude $rootdir/dirsyncroot/$mysqldb.tar"; #Cannot have spaces in directory or file names
delolderthan=14000; #In minutes

# Export data bases
/usr/bin/mysqldump -u $mysqluser -p$mysqlpass $mysqldb > $rootdir/dirsyncroot/$mysqldb.sql
/usr/bin/mysqldump -u $mysqluser -p$mysqlpass $mysqldb2 > $rootdir/dirsyncroot/$mysqldb2.sql
#/usr/bin/mysqldump -u $mysqluser -p$mysqlpass $mysqldb3 > $rootdir/dirsyncroot/$mysqldb3.sql
#/usr/bin/mysqldump -u $mysqluser -p$mysqlpass $mysqldb4 > $rootdir/dirsyncroot/$mysqldb4.sql
#/usr/bin/mysqldump -u $mysqluser -p$mysqlpass $mysqldb5 > $rootdir/dirsyncroot/$mysqldb5.sql
#/usr/bin/mysqldump -u $mysqluser -p$mysqlpass $mysqldb6 > $rootdir/dirsyncroot/$mysqldb6.sql

# Tar files
tar -cf $rootdir/dirsyncroot/$mysqldb.tar $tarstring;

# Make sure you are at the root directory
cd $rootdir/dirsyncroot

# Clean old archives off backup source
ssh -p $sftpport -i $sftpkey $sftpuser@$sftpserver <<EOF
    if [ ! -d $sftpdir ]; then
        mkdir $sftpdir
    fi
    cd "$sftpdir"
    find ./ -maxdepth 1 -mindepth 1 -type d -mmin +$delolderthan -print > directories.txt
    echo "#!/bin/bash" > killdir.sh
    echo -n "while read p; do rm -rf $" >> killdir.sh
    echo -n "p; done < directories.txt" >> killdir.sh
    chmod 700 killdir.sh
    ./killdir.sh
    rm directories.txt
    rm killdir.sh
EOF

# Send files to backup source
sftp -P $sftpport -i $sftpkey $sftpuser@$sftpserver <<EOF
cd "$sftpdir"
mkdir `date '+%Y%m%d'`
chmod 700 `date '+%Y%m%d'`
cd `date '+%Y%m%d'`
put $mysqldb.tar
chmod 600 *
EOF

# Remove tar backup off server
rm $rootdir/dirsyncroot/$mysqldb.sql
rm $rootdir/dirsyncroot/$mysqldb2.sql

# Remove old data directories
for i in `find $rootdir/Data -maxdepth 1 -mindepth 1 -type d -mmin +$delolderthan -print`; do rm -rf $i; done
