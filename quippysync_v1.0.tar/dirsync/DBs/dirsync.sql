-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 23, 2015 at 11:13 AM
-- Server version: 5.5.41-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dirsync`
--

-- --------------------------------------------------------

--
-- Table structure for table `domains`
--

CREATE TABLE IF NOT EXISTS `domains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(512) NOT NULL,
  `type` int(11) NOT NULL,
  `db` varchar(512) NOT NULL,
  `fqdnbak` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `domains`
--

INSERT INTO `domains` (`id`, `domain`, `type`, `db`, `fqdnbak`) VALUES
(3, '', 1, 'ad_template', '');

-- --------------------------------------------------------

--
-- Table structure for table `recovery_attempts`
--

CREATE TABLE IF NOT EXISTS `recovery_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(512) NOT NULL,
  `timestamp` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `autonumber` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `sessionid` varchar(32) NOT NULL,
  `timestamp` int(12) NOT NULL DEFAULT '0',
  `lockout` int(2) NOT NULL DEFAULT '0',
  `username` varchar(75) NOT NULL,
  `password` varchar(1024) NOT NULL,
  `admin` int(11) NOT NULL,
  PRIMARY KEY (`autonumber`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`autonumber`, `firstname`, `lastname`, `sessionid`, `timestamp`, `lockout`, `username`, `password`, `admin`) VALUES
(1, 'c3VwZXI=', 'YWRtaW4=', 'wmHl4yugSzofHbvQRky8crWx0oAqhf6e', 1435114503, 0, 'YWRtaW4=', 'eb8dbdb6074b7fff39dbf85409bd36bfe24eb957', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
