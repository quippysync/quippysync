-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 23, 2015 at 11:13 AM
-- Server version: 5.5.41-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ad_template`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad_all_users`
--

CREATE TABLE IF NOT EXISTS `ad_all_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` varchar(512) NOT NULL,
  `dn` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=705 ;

-- --------------------------------------------------------

--
-- Table structure for table `ad_data`
--

CREATE TABLE IF NOT EXISTS `ad_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` varchar(512) NOT NULL DEFAULT 'N' COMMENT 'This field is for the account names of the sync_data file. In the SPS example, It would be the students names from AD',
  `ou` varchar(512) NOT NULL DEFAULT 'N',
  `dn` varchar(512) NOT NULL DEFAULT 'N',
  `first_name` varchar(512) NOT NULL,
  `last_name` varchar(512) NOT NULL,
  `last_logon` varchar(512) NOT NULL,
  `creation_time` varchar(512) NOT NULL,
  `attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `attrib3` varchar(512) NOT NULL DEFAULT 'N',
  `attrib4` varchar(512) NOT NULL DEFAULT 'N',
  `ous_dn` varchar(512) NOT NULL DEFAULT 'N',
  `ous_script` varchar(512) NOT NULL DEFAULT 'N',
  `ous_group1` varchar(512) NOT NULL DEFAULT 'N',
  `ous_storage_path` varchar(512) NOT NULL DEFAULT 'N',
  `ous_drive_letter` varchar(512) NOT NULL DEFAULT 'N',
  `ous_server_name` varchar(512) NOT NULL DEFAULT 'N',
  `ous_user_share` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib3` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib4` varchar(512) NOT NULL DEFAULT 'N',
  `master_ou` varchar(512) NOT NULL DEFAULT 'N',
  `master_dn` varchar(512) NOT NULL DEFAULT 'N',
  `master_group1` varchar(512) NOT NULL DEFAULT 'N',
  `master_script` varchar(512) NOT NULL DEFAULT 'N',
  `master_storage_path` varchar(512) NOT NULL DEFAULT 'N',
  `master_drive_letter` varchar(512) NOT NULL DEFAULT 'N',
  `master_server_name` varchar(512) NOT NULL DEFAULT 'N',
  `master_user_share` varchar(512) NOT NULL DEFAULT 'N',
  `master_first_name` varchar(512) NOT NULL DEFAULT 'N',
  `master_last_name` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib3` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib4` varchar(512) DEFAULT 'N',
  `match_account` int(11) NOT NULL COMMENT 'Stores a 1 for all records where there is a match between sync_data.sync_account and master_data.master_account',
  `match_move_account` int(11) NOT NULL COMMENT 'Stores a 1 for all records where there is a match between sync_data.account_ou_cat and master_data.account_ou_cat',
  `change_to` varchar(256) NOT NULL,
  `exempt` int(11) NOT NULL,
  `temp1` varchar(512) NOT NULL,
  `temp2` varchar(512) NOT NULL,
  `temp3` varchar(512) NOT NULL,
  `temp4` varchar(512) NOT NULL,
  `temp5` varchar(512) NOT NULL,
  `temp6` varchar(512) NOT NULL,
  `last_logon_temp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=496 ;

-- --------------------------------------------------------

--
-- Table structure for table `ad_disabled`
--

CREATE TABLE IF NOT EXISTS `ad_disabled` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` varchar(512) NOT NULL DEFAULT 'N',
  `dn` varchar(512) NOT NULL DEFAULT 'N',
  `first_name` varchar(512) NOT NULL,
  `last_name` varchar(512) NOT NULL,
  `last_logon` varchar(512) NOT NULL,
  `creation_time` varchar(512) NOT NULL,
  `attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `master_ou` varchar(512) NOT NULL DEFAULT 'N',
  `master_last_name` varchar(512) NOT NULL DEFAULT 'N',
  `master_first_name` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib3` varchar(512) NOT NULL DEFAULT 'N',
  `master_attrib4` varchar(512) DEFAULT 'N',
  `exempt` int(11) NOT NULL,
  `temp1` varchar(512) NOT NULL,
  `temp2` varchar(512) NOT NULL,
  `temp3` varchar(512) NOT NULL,
  `temp4` varchar(512) NOT NULL,
  `last_logon_temp` int(10) unsigned NOT NULL,
  `remove1` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ad_master_data`
--

CREATE TABLE IF NOT EXISTS `ad_master_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` varchar(512) NOT NULL DEFAULT 'N' COMMENT 'This field is for the account names of the master account file. In the SPS example, It would be the students names from PS',
  `ou` varchar(512) NOT NULL DEFAULT 'N',
  `first_name` varchar(512) NOT NULL DEFAULT 'N',
  `last_name` varchar(512) NOT NULL DEFAULT 'N',
  `attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `attrib3` varchar(512) NOT NULL DEFAULT 'N',
  `attrib4` varchar(512) NOT NULL DEFAULT 'N',
  `ous_dn` varchar(512) NOT NULL DEFAULT 'N',
  `ous_script` varchar(512) NOT NULL DEFAULT 'N',
  `ous_group1` varchar(512) NOT NULL DEFAULT 'N',
  `ous_storage_path` varchar(512) NOT NULL DEFAULT 'N',
  `ous_drive_letter` varchar(512) NOT NULL DEFAULT 'N',
  `ous_server_name` varchar(512) NOT NULL DEFAULT 'N',
  `ous_user_share` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib3` varchar(512) NOT NULL DEFAULT 'N',
  `ous_attrib4` varchar(512) NOT NULL DEFAULT 'N',
  `ad_ou` varchar(512) NOT NULL DEFAULT 'N',
  `ad_dn` varchar(512) NOT NULL DEFAULT 'N',
  `ad_attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `ad_attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `ad_attrib3` varchar(512) NOT NULL DEFAULT 'N',
  `ad_attrib4` varchar(512) NOT NULL DEFAULT 'N',
  `disabled_attrib1` varchar(512) NOT NULL DEFAULT 'N',
  `disabled_attrib2` varchar(512) NOT NULL DEFAULT 'N',
  `match_account` int(11) NOT NULL DEFAULT '0' COMMENT 'Stores a 1 for all records where there is a match between sync_data.sync_account and master_data.master_account',
  `match_disabled_account` int(11) NOT NULL DEFAULT '0' COMMENT 'Stores a 1 for all records where there is a match between disabled.disabled_account.and master_data.master_account',
  `exempt` int(11) NOT NULL,
  `temp1` varchar(512) NOT NULL,
  `temp2` varchar(512) NOT NULL,
  `temp3` varchar(512) NOT NULL,
  `temp4` varchar(512) NOT NULL,
  `temp5` varchar(512) NOT NULL,
  `temp6` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1644 ;

-- --------------------------------------------------------

--
-- Table structure for table `ad_ous`
--

CREATE TABLE IF NOT EXISTS `ad_ous` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ou` varchar(512) NOT NULL,
  `dn` varchar(512) NOT NULL,
  `script` varchar(512) NOT NULL,
  `group1` varchar(512) NOT NULL,
  `storage_path` varchar(512) NOT NULL,
  `drive_letter` varchar(512) NOT NULL,
  `server_name` varchar(512) NOT NULL,
  `user_share` varchar(512) NOT NULL,
  `attrib1` varchar(512) NOT NULL,
  `attrib2` varchar(512) NOT NULL,
  `attrib3` varchar(512) NOT NULL,
  `attrib4` varchar(512) NOT NULL,
  `temp1` varchar(512) NOT NULL,
  `temp2` varchar(512) NOT NULL,
  `temp3` varchar(512) NOT NULL,
  `temp4` varchar(512) NOT NULL,
  `temp5` varchar(512) NOT NULL,
  `temp6` varchar(512) NOT NULL,
  `include_in_export` tinyint(1) NOT NULL COMMENT '1 means the ou should be included when deciding what OUs to export from the AD. This is important because csvde.exe expor users in sub OUs and we don''t want duplicates.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `ad_ou_exemptions`
--

CREATE TABLE IF NOT EXISTS `ad_ou_exemptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` varchar(512) NOT NULL,
  `dn` varchar(512) NOT NULL,
  `creation_time` varchar(512) NOT NULL,
  `last_logon` varchar(512) NOT NULL,
  `first_name` varchar(512) NOT NULL,
  `last_name` varchar(512) NOT NULL,
  `type` varchar(512) NOT NULL,
  `remove1` int(11) NOT NULL DEFAULT '0',
  `last_logon_temp` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=131 ;

-- --------------------------------------------------------

--
-- Table structure for table `exemptions`
--

CREATE TABLE IF NOT EXISTS `exemptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exemption` varchar(512) NOT NULL,
  `type` varchar(512) NOT NULL,
  `description` varchar(512) NOT NULL,
  `date` int(11) NOT NULL,
  `iteration` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=386 ;

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE IF NOT EXISTS `options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `option` varchar(512) NOT NULL COMMENT '0=common_option, 1=google_option, 2=ad_option',
  `value` varchar(1024) NOT NULL,
  `description` text NOT NULL,
  `read_only` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `type`, `option`, `value`, `description`, `read_only`) VALUES
(10, 2, 'ad_master_attrib_string', '"accountid,first_name,last_name,ou"', 'These are the order of fields in the g_master_data file.', 0),
(11, 2, 'ad_data_attrib_string', '"dn,last_name,first_name,creation_time,last_logon,accountid,ou"', '', 0),
(12, 2, 'ad_disabled_attrib_string', '"dn,last_name,first_name,creation_time,last_logon,accountid"', 'last_logon, last_name, and first_name are need for identifying info for cleaning. The full name is in there because google insists on giving it.', 0),
(14, 2, 'ad_fqdn_suffix', '"myfqdnsuffix.lcl"', '', 0),
(15, 2, 'default_password', '"password"', '', 0),
(17, 2, 'master_data_file', '"master.csv"', '', 0),
(21, 2, 'ad_ous_exemptions_attrib_string', '"dn,last_name,first_name,creation_time,last_logon,accountid"', '', 0),
(23, 2, 'log_group_removals', '0', 'If you try to remove a user from a group of which they are not a part, it will throw an error and halt the process. It should only be set to 1 if you know all users are members of the group specified in the g_ous table', 0),
(25, 2, 'ad_master_separator', ',', 'Character used for delimiting in the master file', 0),
(27, 2, 'ad_master_num_separators', '3', 'Number of separators expected in the master file', 0),
(29, 2, 'ad_regex', '"ad_master_data|0>first_name|0>/^[0-9a-zA-Z\\s\\-\\''\\.]{1,35}$/|1>ad_master_data|0>last_name|0>/^[0-9a-zA-Z\\s\\-\\''\\.]{1,35}$/"', 'This section should be in the format Table1|0>Field1|1>Regex1|0>Table2|0>Field2|0>Regex2\n\nAll characters: /^[0-9a-zA-Z\\s\\~\\`\\^\\{\\}\\[\\]\\/\\$\\#\\@\\!\\%\\&\\*\\|\\-\\_\\+\\=\\(\\)\\<\\>\\''\\"\\:\\;\\?\\,\\.\\\\\\]*$/', 0),
(30, 2, 'ad_charenc', '"text/plain; charset=us-ascii"', 'This is the value of the character encoding of the master file.', 0),
(31, 2, 'max_create', '10', '', 0),
(32, 2, 'max_disable', '10', '', 0),
(33, 2, 'max_move', '10', '', 0),
(34, 2, 'max_enable', '10', '', 0),
(35, 2, 'remove_name_chars', '0', 'If set to 1, it will remove spaces, . -  and '' from g_master_data.accountid.', 0),
(36, 2, 'ad_disabled_ou', 'ou=disabled,dc=mydc,dc=com', 'Don''t put in quotes', 0),
(38, 2, 'ad_email_suffix', '"mydomain.com"', '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
