#!/bin/bash

#     Copyright 2015 Anthony Tranquillo

#     This file is part of Quippysync.

#    Quippysync is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Quippysync is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.


# Set the name of this iteration
    iter="ad_template"

# Get this iterations static options
    source ./dirsyncroot/$iter/AD_Config/static_config.sh

# Get common config options
    source ./Common/common_config.sh;

# Get bash functions
    source ./Common/bash_functions.sh;

# Remove current date directory if there is one
    rm -rf ./Data/$current_date
   
# Make data path directory
    mkdir $data_path;

# Make the working directory and log file
    mkdir $iter_path;
    echo "/////////////////////// $iter Directory Sync Log - $current_date ////////////////////" > $iter_path/bash.log;
    echo " " >> $iter_path/bash.log;
 
# Get ad config options
    $php_path ./dirsyncroot/$iter/AD_Config/get_config.php $mysql_con $iter_path 1>> $iter_path/php.log 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Config/get_config.php" "FAIL: Call $iter/AD_Config/get_config.php" 2;
        checkLog "php" "Error in AD_Config/get_config.php" 10;
    
    chmod 774 $iter_path/ad_options.sh 1>> $iter_path/bash.log 2>> $iter_path/bash.log;
        reportStatus $? "bash" "bash" "SUCCESS: ad_options.sh chmod" "FAIL: ad_options.sh chmod" 2;
    
    source $iter_path/ad_options.sh 1>> $iter_path/bash.log 2>> $iter_path/bash.log;
        reportStatus $? "bash" "bash" "SUCCESS: Include $iter_path/ad_options.sh" "FAIL! Include $iter_path/ad_options.sh" 2;

# Remove users maked for deletion
    source ./dirsyncroot/$iter/AD_Cleaning/remove_accounts.sh 2>> $iter_path/bash.log;
        reportStatus $? "bash" "bash" "SUCCESS: Include $iter/AD_Cleaning/remove_accounts.sh" "FAIL: Include $iter/AD_Cleaning/remove_accounts.sh" 1;

# Get the data
    source ./dirsyncroot/$iter/AD_Get_Data/get_data.sh; 2>> $iter_path/bash.log;
        reportStatus $? "bash" "bash" "SUCCESS: Include $iter/AD_Get_Data/get_data.sh" "FAIL: Include $iter/AD_Get_Data/get_data.sh" 2;

# Clean and check data
    source ./dirsyncroot/$iter/AD_Prepare_Data/prepare_data.sh 2>> $iter_path/bash.log;
        reportStatus $? "bash" "bash" "SUCCESS: Include $iter/AD_Prepare_Data/prepare_data.sh" "FAIL: Include $iter/AD_Prepare_Data/prepare_data.sh" 2;

# Remove Exemptions
    source ./dirsyncroot/$iter/AD_Exemptions/remove_exemptions.sh
        reportStatus $? "bash" "bash" "SUCCESS: Include $iter/AD_Exemptions/remove_exemptions.sh" "FAIL: Include $iter/AD_Exemptions/remove_exemptions.sh" 2;

# Analyze
    $php_path ./dirsyncroot/$iter/AD_Analyze/analyze.php $mysql_con $iter_path $max_create $max_disable $max_move $max_enable 1>> $iter_path/php.log 2>> $iter_path/php.log;
        reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Analyze/analyze.php" "FAIL: Call $iter/AD_Analyze/analyze.php" 2;
        checkLog "php" "FAIL: Error in $iter/AD_Analyze/analyze.php" 10;

# Clear ./Repo/$iter/ad_change_files
    rm ./Repo/$iter/ad_change_files/*

# Copy change files to repo
    cp $iter_path/ad_clean_disabled.txt ./Repo/$iter/ad_change_files
    cp $iter_path/ad_clean_exemptions.txt ./Repo/$iter/ad_change_files
    cp $iter_path/ad_disable.txt ./Repo/$iter/ad_change_files
    cp $iter_path/ad_enable.txt ./Repo/$iter/ad_change_files
    cp $iter_path/ad_create.txt ./Repo/$iter/ad_change_files
    cp $iter_path/ad_move.txt ./Repo/$iter/ad_change_files
    
    if [ -f $iter_path/dirsync_errors.log ];
        then cp $iter_path/dirsync_errors.log ./Repo/$iter/ad_change_files;
        else echo "0" > ./Repo/$iter/ad_change_files/dirsync_errors.log;
    fi
    
    if [ -f $iter_path/dirsync_fatal_errors.log ];
        then cp $iter_path/dirsync_fatal_errors.log ./Repo/$iter/ad_change_files;
        else echo "0" > ./Repo/$iter/ad_change_files/dirsync_fatal_errors.log;
    fi
    
# If testing run misc_testing_tasks.sh
    if [ "$testing" == "y" ]
    then
            ### Get all users so you can make sure the users you are changing are not being changed to some username already elsewhere in the directory
            source ./dirsyncroot/$iter/AD_Testing/misc_testing_tasks.sh
                reportStatus $? "bash" "bash" "SUCCESS: Call $iter/AD_Testing/misc_testing_tasks.sh" "FAIL: Call $iter/AD_Testing/misc_testing_tasks.sh" 2;
    fi
    
# Remove ad_test_vars.sh
    rm ad_test_vars.sh

# Close the log file
echo "/////////////////////// End of log ////////////////////" >> $iter_path/bash.log;
