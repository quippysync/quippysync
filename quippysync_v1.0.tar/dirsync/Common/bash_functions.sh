#     Copyright 2015 Anthony Tranquillo

#     This file is part of Quippysync.

#    Quippysync is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Quippysync is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Quippysync.  If not, see <http://www.gnu.org/licenses/>.

function reportStatus(){
	# Usage: reportStatus $? "successlog" "faillog" "SUCCESS: " "FAIL: " fatality_level;
    # Fatality levels: 0 = nothing, 1 = report, 2 = exit script
    
    if [ $1 -eq 0 ]
        then echo "$4 - " `date +%k:%M_%x` >> "$iter_path/$2.log";
        else echo "$5 - " `date +%k:%M_%x` >> "$iter_path/$3.log";
            
            if [ $6 -eq  1 ]
                then echo "$5 - " `date +%k:%M_%x` " - Fatality Level: $6" >> "$iter_path/dirsync_errors.log";
            fi
        
            if [ $6 -eq 2 ]
                then echo "$5 - " `date +%k:%M_%x` " - Fatality Level: $6" >> "$iter_path/dirsync_fatal_errors.log";
            fi
    fi
}

function checkLog(){
	# Usage: checkLog "log" "message" "size_threshold";
	size=$(wc -c "$iter_path/$1.log" | cut -f 1 -d ' ');

    if [ $size -gt $3 ]
    then
        echo "$2 - " `date +%k:%M_%x` >> "$iter_path/dirsync_fatal_errors.log";
        echo "$2 - " `date +%k:%M_%x` >> "$iter_path/$1.log";
    fi
}